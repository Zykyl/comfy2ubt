# 文本前添加

添加文本前缀节点通过将指定字符串添加到每个输入文本的开头来修改文本。该节点接收文本和前缀作为输入，然后返回合并后的结果。

## 输入

| 参数 | 描述 | 数据类型 | 必填 | 范围 |
| --- | --- | --- | --- | --- |
| `text` | 将要添加前缀的文本。 | STRING | 是 |  |
| `前缀` | 要添加到文本开头的字符串（默认值：""）。 | STRING | 否 |  |

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `文本` | 在前端添加了前缀的结果文本。 | STRING |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AddTextPrefix/zh.md)

---
**Source fingerprint (SHA-256):** `7f1282b1b84ea06a96ecefdec8e9e684cb6e7d3e618250dfb6e54d01f9e9ba87`
