# 텍스트 접두사 추가

Add Text Prefix 노드는 각 입력 텍스트의 시작 부분에 지정된 문자열을 추가하여 텍스트를 수정합니다. 이 노드는 텍스트와 접두사를 입력으로 받아 결합된 결과를 반환합니다.

## 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 여부 | 범위 |
| --- | --- | --- | --- | --- |
| `text` | 접두사가 추가될 텍스트입니다. | STRING | 예 |  |
| `prefix` | 텍스트 시작 부분에 추가할 문자열입니다(기본값: ""). | STRING | 아니요 |  |

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
| --- | --- | --- |
| `texts` | 접두사가 앞에 추가된 결과 텍스트입니다. | STRING |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AddTextPrefix/ko.md)

---
**Source fingerprint (SHA-256):** `7f1282b1b84ea06a96ecefdec8e9e684cb6e7d3e618250dfb6e54d01f9e9ba87`
