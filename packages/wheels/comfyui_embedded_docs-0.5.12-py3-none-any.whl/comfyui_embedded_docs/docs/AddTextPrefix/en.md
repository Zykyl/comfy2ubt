# Add Text Prefix (DEPRECATED)

The Add Text Prefix node modifies text by adding a specified string to the beginning of each input text. It takes the text and a prefix as input, then returns the combined result.

**Note:** This node is deprecated and superseded by the Concatenate Text node.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `text` | The text to which the prefix will be added. | STRING | Yes |  |
| `prefix` | The string to add to the beginning of the text (default: ""). | STRING | No |  |

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `text` | The resulting text with the prefix added to the front. | STRING |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AddTextPrefix/en.md)

---
**Source fingerprint (SHA-256):** `71744a8dc3056b8f20eb2cb7ac16002ce86e214a660aa1d145f501d6d7dc5b53`
