# 音频调整音量

AudioAdjustVolume 节点通过以分贝（dB）为单位调整音量来修改音频的响度。它接收音频输入，并根据指定的音量级别应用增益系数，其中正值增加音量，负值降低音量。该节点返回与原始音频采样率相同的修改后音频。

## 输入

| 参数 | 描述 | 数据类型 | 是否必填 | 范围 |
| --- | --- | --- | --- | --- |
| `音频` | 待处理的音频输入 | AUDIO | 是 | - |
| `音量` | 以分贝（dB）为单位的音量调整值。0 = 无变化，+6 = 加倍，-6 = 减半，以此类推（默认值：1） | INT | 是 | -100 至 100 |

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `音频` | 经过音量调整后的处理音频 | AUDIO |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioAdjustVolume/zh.md)

---
**Source fingerprint (SHA-256):** `0436765680671551239f7a89b575cdfb22590fbe662bdfe5da01bd1cd5c496ed`
