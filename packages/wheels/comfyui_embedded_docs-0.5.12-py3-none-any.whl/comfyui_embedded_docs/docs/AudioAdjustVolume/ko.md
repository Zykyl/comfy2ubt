# 오디오 볼륨 조절

AudioAdjustVolume 노드는 데시벨(dB) 단위의 볼륨 조정을 적용하여 오디오의 음량을 수정합니다. 오디오 입력을 받아 지정된 볼륨 레벨에 따라 게인(gain) 계수를 적용하며, 양수 값은 볼륨을 높이고 음수 값은 낮춥니다. 이 노드는 원본과 동일한 샘플 레이트로 수정된 오디오를 반환합니다.

## 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 여부 | 범위 |
| --- | --- | --- | --- | --- |
| `오디오` | 처리할 오디오 입력 | AUDIO | 예 | - |
| `volume` | 데시벨(dB) 단위의 볼륨 조정. 0 = 변경 없음, +6 = 두 배, -6 = 절반 등 (기본값: 1) | INT | 예 | -100 ~ 100 |

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
| --- | --- | --- |
| `오디오` | 볼륨 레벨이 조정된 처리된 오디오 | AUDIO |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioAdjustVolume/ko.md)

---
**Source fingerprint (SHA-256):** `0436765680671551239f7a89b575cdfb22590fbe662bdfe5da01bd1cd5c496ed`
