# 加载音频编码器

## 概述

AudioEncoderLoader 节点从存储在 `audio_encoders` 文件夹中的文件加载音频编码器模型。它接收音频编码器模型的文件名作为输入，并返回已加载的模型，随后可在工作流中用于音频处理任务。如果所选文件不包含有效的音频编码器模型，该节点会引发错误。

## 输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
| --- | --- | --- | --- | --- |
| `音频编码器` | 选择要从音频编码器文件夹中加载哪个音频编码器模型文件 | COMBO | 是 | `audio_encoders` 文件夹中可用音频编码器文件的列表 |

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `audio_encoder` | 已加载的音频编码器模型，可用于音频处理工作流 | AUDIO_ENCODER |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioEncoderLoader/zh.md)

---
**Source fingerprint (SHA-256):** `780d0c7fcf571e5ef02d273791e5d2e894baa6d5900d845ed65e9ce669769f7e`
