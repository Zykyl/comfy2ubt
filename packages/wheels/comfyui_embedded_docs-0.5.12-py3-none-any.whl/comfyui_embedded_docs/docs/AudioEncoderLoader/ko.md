# 오디오 인코더 로더

## 개요

AudioEncoderLoader 노드는 `audio_encoders` 폴더에 저장된 파일에서 오디오 인코더 모델을 로드합니다. 오디오 인코더 모델의 파일 이름을 입력으로 받아 로드된 모델을 반환하며, 이 모델은 워크플로에서 오디오 처리 작업에 사용할 수 있습니다. 선택한 파일에 유효한 오디오 인코더 모델이 포함되어 있지 않으면 노드에서 오류를 발생시킵니다.

## 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 | 범위 |
| --- | --- | --- | --- | --- |
| `audio_encoder_name` | 오디오 인코더 폴더에서 로드할 오디오 인코더 모델 파일을 선택합니다 | COMBO | 예 | `audio_encoders` 폴더에서 사용 가능한 오디오 인코더 파일 목록 |

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
| --- | --- | --- |
| `audio_encoder` | 로드된 오디오 인코더 모델로, 오디오 처리 워크플로에서 사용할 준비가 되어 있습니다 | AUDIO_ENCODER |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioEncoderLoader/ko.md)

---
**Source fingerprint (SHA-256):** `780d0c7fcf571e5ef02d273791e5d2e894baa6d5900d845ed65e9ce669769f7e`
