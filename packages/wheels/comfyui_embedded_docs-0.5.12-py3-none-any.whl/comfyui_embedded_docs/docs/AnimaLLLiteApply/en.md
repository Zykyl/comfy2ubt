# Apply Anima LLLite

AnimaLLLiteApply applies a lightweight animation patch to a diffusion model, enabling controlled image-to-image generation with adjustable strength and timing. It integrates a pre-configured model patch with an input image and optional mask, modifying the model's attention and MLP layers to influence the generation process.

## Inputs

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `model` | The base diffusion model to apply the patch to | MODEL | Yes | |
| `model_patch` | The pre-configured animation patch to apply | MODEL_PATCH | Yes | |
| `image` | The reference image to guide the generation. Only the first 3 color channels (RGB) are used | IMAGE | Yes | |
| `strength` | The strength of the patch effect (default: 1.0, step: 0.01) | FLOAT | Yes | -10.0 to 10.0 |
| `start_percent` | The percentage of the denoising process at which the patch starts taking effect (default: 0.0, step: 0.001) | FLOAT | Yes | 0.0 to 1.0 |
| `end_percent` | The percentage of the denoising process at which the patch stops taking effect (default: 1.0, step: 0.001) | FLOAT | Yes | 0.0 to 1.0 |
| `mask` | An optional mask to limit the patch effect to specific areas of the image | MASK | No | |

**Note on parameter constraints:** If the `model_patch` has 4 input channels and no `mask` is provided, a zero mask is automatically created to match the image dimensions. If the `model_patch` does not have 4 input channels, the `mask` parameter is ignored and set to `None`. Only the first 3 color channels of the input image are used. This node is marked as experimental in ComfyUI.

## Outputs

| Output Name | Description | Data Type |
|-------------|-------------|-----------|
| `MODEL` | The patched diffusion model with the animation patch applied | MODEL |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AnimaLLLiteApply/en.md)

---
**Source fingerprint (SHA-256):** `48e455b767509a5a8c329365d5ffded86d6f4545d575c9fdc5ffbaf4da7c2287`
