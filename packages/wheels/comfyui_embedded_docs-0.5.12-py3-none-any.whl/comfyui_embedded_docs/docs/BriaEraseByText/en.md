# BriaEraseByText

This node removes an object described in plain text from an image using Bria. Bria re-renders the whole frame at about 1 megapixel, so the result is not pixel-aligned with the input.

## Inputs

### Common Inputs

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `image` | The image from which the named object should be removed. | IMAGE | Yes | - |
| `object_name` | Name of the object to remove, such as 'the lamp'. Several objects can be named at once, such as 'the phone and the pencils'. Naming something that is not in the picture still returns a re-rendered image, and the request is still billed. Must be at least 1 character long (default: empty). | STRING | Yes | - |
| `moderation` | Moderation settings. Selects whether the optional moderation controls are shown. | DYNAMIC_COMBO | Yes | `"false"`<br>`"true"` |

### Moderation Inputs

These parameters appear when `moderation` is set to `"true"`.

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `visual_input_moderation` | Enables content moderation on the input image (default: false). | BOOLEAN | No | true<br>false |
| `visual_output_moderation` | Enables content moderation on the generated output image (default: false). | BOOLEAN | No | true<br>false |

## Outputs

| Output Name | Description | Data Type |
|-------------|-------------|-----------|
| `IMAGE` | The re-rendered image with the named object removed. | IMAGE |
| `structured_prompt` | Structured description of the edited image, for a follow-up edit with Bria FIBO Image Edit. | STRING |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaEraseByText/en.md)

---
**Source fingerprint (SHA-256):** `51ac362bea731251c99905172c41cdebb5165e7564c508f13aa43cf9072964ef`
