# BriaEraseByText

此节点使用 Bria 从图像中移除用纯文本描述的对象。Bria 会以约 1 百万像素重新渲染整个画面，因此结果与输入图像并非逐像素对齐。

## 输入

### 通用输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `图像` | 要从中移除指定对象的图像。 | IMAGE | 是 | - |
| `object_name` | 要移除的对象名称，例如 'the lamp'。可以一次性指定多个对象，例如 'the phone and the pencils'。即使指定的对象不在图片中，仍会返回并计费一张重新渲染的图像。长度必须至少为 1 个字符（默认：空）。 | STRING | 是 | - |
| `内容审核` | 审核设置。用于选择是否显示可选的审核控制项。 | DYNAMIC_COMBO | 是 | `"false"`<br>`"true"` |

### 审核输入

当 `moderation` 设置为 `"true"` 时，会出现以下参数。

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `visual_input_moderation` | 对输入图像启用内容审核（默认：false）。 | BOOLEAN | 否 | true<br>false |
| `visual_output_moderation` | 对生成的输出图像启用内容审核（默认：false）。 | BOOLEAN | 否 | true<br>false |

## 输出

| 输出名称 | 描述 | 数据类型 |
|-------------|-------------|-----------|
| `IMAGE` | 移除指定对象后重新渲染的图像。 | IMAGE |
| `structured_prompt` | 编辑后图像的结构化描述，可用于 Bria FIBO Image Edit 的后续编辑。 | STRING |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaEraseByText/zh.md)

---
**Source fingerprint (SHA-256):** `51ac362bea731251c99905172c41cdebb5165e7564c508f13aa43cf9072964ef`
