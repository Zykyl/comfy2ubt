# BriaEraseByText

이 노드는 Bria를 사용하여 일반 텍스트로 설명된 개체를 이미지에서 제거합니다. Bria는 약 100만 화소로 전체 프레임을 다시 렌더링하므로 결과는 입력과 픽셀 단위로 정렬되지 않습니다.

## 입력

### 공통 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 | 범위 |
|-----------|-------------|-----------|----------|-------|
| `이미지` | 이름이 지정된 개체를 제거할 대상 이미지입니다. | IMAGE | 예 | - |
| `object_name` | 제거할 개체의 이름입니다(예: 'the lamp'). 'the phone and the pencils'와 같이 여러 개체를 한 번에 지정할 수 있습니다. 그림에 없는 항목의 이름을 지정하더라도 다시 렌더링된 이미지가 반환되고 요금이 청구됩니다. 최소 1자 이상이어야 합니다(기본값: 비어 있음). | STRING | 예 | - |
| `검토` | 검열 설정입니다. 선택적 검열 제어를 표시할지 여부를 선택합니다. | DYNAMIC_COMBO | 예 | `"false"`<br>`"true"` |

### 검열 입력

이 매개변수들은 `moderation`이 `"true"`로 설정된 경우 나타납니다.

| 매개변수 | 설명 | 데이터 타입 | 필수 | 범위 |
|-----------|-------------|-----------|----------|-------|
| `visual_input_moderation` | 입력 이미지에 대한 콘텐츠 검열을 활성화합니다(기본값: false). | BOOLEAN | 아니요 | true<br>false |
| `visual_output_moderation` | 생성된 출력 이미지에 대한 콘텐츠 검열을 활성화합니다(기본값: false). | BOOLEAN | 아니요 | true<br>false |

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
|-------------|-------------|-----------|
| `IMAGE` | 지정된 개체가 제거된 다시 렌더링된 이미지입니다. | IMAGE |
| `structured_prompt` | 편집된 이미지에 대한 구조화된 설명으로, Bria FIBO Image Edit을 사용한 후속 편집에 사용됩니다. | STRING |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaEraseByText/ko.md)

---
**Source fingerprint (SHA-256):** `51ac362bea731251c99905172c41cdebb5165e7564c508f13aa43cf9072964ef`
