# 文本后添加

此节点将指定的后缀附加到输入文本字符串的末尾。它接收原始文本和后缀作为输入，然后返回组合后的结果。

## 输入

| 参数 | 描述 | 数据类型 | 是否必填 | 范围 |
| --- | --- | --- | --- | --- |
| `text` | 将添加后缀的原始文本。 | STRING | 是 |  |
| `后缀` | 要添加到文本的后缀（默认值：""）。 | STRING | 否 |  |

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `文本` | 附加后缀后得到的结果文本。 | STRING |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AddTextSuffix/zh.md)

---
**Source fingerprint (SHA-256):** `5dd75a9a29709a35343ec0dce144d2eb27a6e7aef5cb0b9245329c678897a763`
