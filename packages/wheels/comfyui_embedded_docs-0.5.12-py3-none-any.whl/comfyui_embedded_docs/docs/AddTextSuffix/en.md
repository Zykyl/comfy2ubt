# Add Text Suffix (DEPRECATED)

This node appends a specified suffix to the end of an input text string. It takes the original text and the suffix as inputs, then returns the combined result. **This node is deprecated** and superseded by the Concatenate Text node.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `text` | The original text to which the suffix will be added. | STRING | Yes |  |
| `suffix` | The suffix to add to the text (default: ""). | STRING | No |  |

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `text` | The resulting text after the suffix has been appended. | STRING |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AddTextSuffix/en.md)

---
**Source fingerprint (SHA-256):** `9b73a9352d21feb5041de550cc4463222c9ccbc1ef4937415d4dc8c5648d3a90`
