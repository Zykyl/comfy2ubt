# 텍스트 접미사 추가

이 문서는 AI가 생성했습니다. 오류를 발견하거나 개선 제안이 있으시면 언제든지 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AddTextSuffix/en.md)

이 노드는 입력 텍스트 문자열의 끝에 지정된 접미사를 추가합니다. 원본 텍스트와 접미사를 입력으로 받아 결합된 결과를 반환합니다.

## 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 여부 | 범위 |
| --- | --- | --- | --- | --- |
| `text` | 접미사가 추가될 원본 텍스트입니다. | STRING | 예 |  |
| `suffix` | 텍스트에 추가할 접미사입니다(기본값: ""). | STRING | 아니요 |  |

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
| --- | --- | --- |
| `texts` | 접미사가 추가된 후의 결과 텍스트입니다. | STRING |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AddTextSuffix/ko.md)

---
**Source fingerprint (SHA-256):** `5dd75a9a29709a35343ec0dce144d2eb27a6e7aef5cb0b9245329c678897a763`
