# Bria FIBO 图像编辑

Bria FIBO 图像编辑节点根据文本指令编辑现有图像。它会将图像和提示词发送到 Bria API，由 FIBO 模型生成编辑后的版本。可选遮罩可将修改限制在特定区域。

## 输入

### 通用输入

| 参数 | 描述 | 数据类型 | 必填 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `model` | 用于图像编辑的模型版本。 | COMBO | 是 | `"FIBO"` |
| `image` | 您要编辑的输入图像。 | IMAGE | 是 | - |
| `prompt` | 编辑图像的指令（默认：空）。 | STRING | 是 | - |
| `negative_prompt` | 描述您不希望出现在编辑后图像中的内容的文本（默认：空）。 | STRING | 是 | - |
| `structured_prompt` | 包含 JSON 格式的结构化编辑提示词字符串。需要精确、程序化控制时，可使用此参数代替常规提示词（默认：空）。 | STRING | 是 | - |
| `seed` | 用于初始化随机生成过程的数字，确保结果可复现（默认：1）。 | INT | 是 | 1 到 2147483647 |
| `guidance_scale` | 数值越大，图像越贴近提示词（默认：3）。 | FLOAT | 是 | 3.0 到 5.0 |
| `steps` | 模型执行的去噪步数（默认：50）。 | INT | 是 | 20 到 50 |
| `moderation` | 审核设置。选择 `"true"` 会显示更多审核选项。 | DYNAMIC_COMBO | 是 | `"false"`<br>`"true"` |
| `mask` | 如果省略，编辑操作将应用于整张图像。 | MASK | 否 | - |

### 审核输入

当 `moderation` 设置为 `"true"` 时，以下额外输入将可用：

| 参数 | 描述 | 数据类型 | 必填 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `prompt_content_moderation` | 是否对提示词文本进行不当内容审核（默认：false）。 | BOOLEAN | 否 | `true`<br>`false` |
| `visual_input_moderation` | 是否对输入图像进行不当内容审核（默认：false）。 | BOOLEAN | 否 | `true`<br>`false` |
| `visual_output_moderation` | 是否对编辑后的输出图像进行不当内容审核（默认：true）。 | BOOLEAN | 否 | `true`<br>`false` |

**重要约束：**

- `prompt` 和 `structured_prompt` 中至少有一个必须非空。如果两者都为空，节点将报错。
- 当 `moderation` 设置为 `"true"` 时，将显示上述三个审核输入。

## 输出

| 输出名称 | 描述 | 数据类型 |
|-------------|-------------|-----------|
| `IMAGE` | Bria API 返回的编辑后图像。 | IMAGE |
| `structured_prompt` | 编辑过程中使用或生成的结构化提示词。 | STRING |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaImageEditNode/zh.md)

---
**Source fingerprint (SHA-256):** `e66aaa563a82407408f25b289011a491c8b158822fc2db8912daf73731750081`
