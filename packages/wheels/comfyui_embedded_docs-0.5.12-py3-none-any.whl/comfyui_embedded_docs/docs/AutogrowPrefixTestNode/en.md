# AutogrowPrefixTestNode

The AutogrowPrefixTestNode is a logic node that tests the autogrow input feature. It accepts a dynamic number of float inputs, converts each value into text, combines them into a comma-separated string, and outputs that string.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `autogrow` | A dynamic input group that accepts between 1 and 10 float values. Each value is a floating-point number, and the generated inputs are named with the prefix `float`. | AUTOGROW | Yes | 1 to 10 inputs |

**Note:** The `autogrow` input is a special dynamic input. You can add multiple float inputs to this group, from a minimum of 1 up to a maximum of 10. The node processes all provided values and includes every connected input in the output string.

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `output` | A single string containing all the input float values, separated by commas. | STRING |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AutogrowPrefixTestNode/en.md)

---
**Source fingerprint (SHA-256):** `9b815f59961a4c661815f44b9c78e15e9084db1e4be89d502b9d92438f18e70b`
