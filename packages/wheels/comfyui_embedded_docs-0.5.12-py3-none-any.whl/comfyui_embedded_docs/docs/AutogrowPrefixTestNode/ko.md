# AutogrowPrefixTestNode

AutogrowPrefixTestNode는 자동 증가(autogrow) 입력 기능을 테스트하는 로직 노드입니다. 동적인 개수의 float 입력을 받아 각 값을 텍스트로 변환한 후, 이를 쉼표로 구분된 문자열로 결합하고 해당 문자열을 출력합니다.

## 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 | 범위 |
| --- | --- | --- | --- | --- |
| `autogrow` | 1개에서 10개 사이의 float 값을 허용하는 동적 입력 그룹입니다. 각 값은 부동 소수점 숫자이며, 생성된 입력은 `float` 접두사로 이름이 지정됩니다. | AUTOGROW | 예 | 1~10개 입력 |

**참고:** `autogrow` 입력은 특수한 동적 입력입니다. 이 그룹에는 최소 1개에서 최대 10개까지의 float 입력을 추가할 수 있습니다. 노드는 제공된 모든 값을 처리하며 연결된 모든 입력을 출력 문자열에 포함합니다.

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
| --- | --- | --- |
| `output` | 모든 입력 float 값을 쉼표로 구분하여 포함하는 단일 문자열입니다. | STRING |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AutogrowPrefixTestNode/ko.md)

---
**Source fingerprint (SHA-256):** `9b815f59961a4c661815f44b9c78e15e9084db1e4be89d502b9d92438f18e70b`
