# AutogrowPrefixTestNode

AutogrowPrefixTestNode 是一个逻辑节点，用于测试自动增长输入功能。它接受动态数量的 FLOAT 输入，将每个值转换为文本，组合成以逗号分隔的字符串，并输出该字符串。

## 输入
| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `autogrow` | 一个动态输入组，接受 1 到 10 个 FLOAT 值。每个值都是一个浮点数，生成的输入以 `float` 前缀命名。 | AUTOGROW | 是 | 1 到 10 inputs |

**注意：** `autogrow` 输入是一个特殊的动态输入。您可以向此组中添加多个 FLOAT 输入，最少 1 个，最多 10 个。该节点会处理所有提供的值，并将每个已连接的输入都包含在输出字符串中。

## 输出
| Output Name | Description | Data Type |
| --- | --- | --- |
| `output` | 包含所有输入浮点值（以逗号分隔）的单个字符串。 | STRING |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AutogrowPrefixTestNode/zh.md)

---
**Source fingerprint (SHA-256):** `9b815f59961a4c661815f44b9c78e15e9084db1e4be89d502b9d92438f18e70b`
