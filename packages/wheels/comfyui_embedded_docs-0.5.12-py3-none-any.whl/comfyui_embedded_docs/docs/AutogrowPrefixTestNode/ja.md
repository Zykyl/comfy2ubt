# AutogrowPrefixTestNode

AutogrowPrefixTestNodeは、autogrow入力機能をテストするロジックノードです。動的な数のfloat入力を受け付け、各値をテキストに変換してカンマ区切りの文字列に結合し、その文字列を出力します。

## 入力

| パラメータ | 説明 | データ型 | 必須 | 範囲 |
| --- | --- | --- | --- | --- |
| `autogrow` | 1〜10個のfloat値を受け入れる動的入力グループです。各値は浮動小数点数で、生成される入力には接頭辞`float`が付いた名前が付けられます。 | AUTOGROW | はい | 1〜10 inputs |

**注記:** `autogrow`入力は特別な動的入力です。このグループには、最小1つから最大10個までの複数のfloat入力を追加できます。ノードは提供されたすべての値を処理し、接続されたすべての入力を出力文字列に含めます。

## 出力

| 出力名 | 説明 | データ型 |
| --- | --- | --- |
| `output` | すべての入力float値をカンマで区切った単一の文字列です。 | STRING |

> このドキュメントは AI によって生成されました。エラーを見つけた場合や改善のご提案がある場合は、ぜひ貢献してください！ [GitHub で編集](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AutogrowPrefixTestNode/ja.md)

---
**Source fingerprint (SHA-256):** `9b815f59961a4c661815f44b9c78e15e9084db1e4be89d502b9d92438f18e70b`
