# Adjust Contrast

The Adjust Contrast node adjusts the contrast of an input image by scaling the difference between light and dark areas around the midpoint of the color range. A factor of 1.0 leaves the image unchanged, values below 1.0 reduce contrast, and values above 1.0 increase contrast.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `image` | The input image to have its contrast adjusted. | IMAGE | Yes | - |
| `factor` | Contrast factor. 1.0 = no change, <1.0 = less contrast, >1.0 = more contrast. (default: 1.0) | FLOAT | No | 0.0 - 2.0 |

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `image` | The resulting image with adjusted contrast. Pixel values are clamped to the 0.0–1.0 range. If the input image has an alpha channel, that channel is preserved unchanged. | IMAGE |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AdjustContrast/en.md)

---
**Source fingerprint (SHA-256):** `489f840cc3d98339a5cf7b55e9179c60878c58b2f992740796c7d49642e05932`
