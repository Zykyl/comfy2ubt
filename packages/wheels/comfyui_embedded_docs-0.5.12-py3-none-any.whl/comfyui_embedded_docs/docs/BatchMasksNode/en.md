# Batch Masks

The Batch Masks node combines multiple individual mask inputs into a single batch. It takes a variable number of mask inputs and outputs them as a single batched mask tensor, allowing for batch processing of masks in subsequent nodes. If the input masks have different sizes, they are automatically resized to match the dimensions of the first mask.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `mask` | The mask inputs to combine into a batch. At least one mask is required. You can add up to 50 masks total by clicking the "+" button on the node. If masks have different sizes, they are automatically resized to match the first mask's dimensions. | MASK | Yes | 1 to 50 masks |

**Note:** This node uses an autogrow input template. You must connect at least one mask. You can add up to 49 more mask inputs for a total of 50 masks. All connected masks will be combined into a single batch. If masks have different heights or widths, they are automatically resized to match the dimensions of the first mask using bilinear interpolation.

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `output` | A single batched mask containing all the input masks stacked together. If no masks are provided, returns None. | MASK |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BatchMasksNode/en.md)

---
**Source fingerprint (SHA-256):** `7e9bc4be72c7fa8fceab2cf167c72b7e1ff858c0281d977f2ad3ab433d9d58d6`
