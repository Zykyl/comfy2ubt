# 基本引导器

BasicGuider 节点为采样过程创建了一种简单的引导机制。它接受 `model` 模型和 `conditioning` 条件数据作为输入，并生成一个引导器（guider）对象，该对象可在采样过程中用于引导生成。此节点提供了受控生成所需的基础引导功能。

## 输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
| --- | --- | --- | --- | --- |
| `模型` | 用于引导的模型 | MODEL | 是 | - |
| `条件` | 用于引导生成过程的条件数据 | CONDITIONING | 是 | - |

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `GUIDER` | 可在采样过程中用于引导生成的引导器对象 | GUIDER |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BasicGuider/zh.md)

---
**Source fingerprint (SHA-256):** `8ea6b56be58ae99baaf13a04c4fadbf8ad921801d8f2ce2aecce768cc34a3b20`
