# 基本ガイダー

BasicGuiderノードは、サンプリングプロセス用のシンプルなガイダンスメカニズムを作成します。モデルとconditioningデータを入力として受け取り、サンプリング中に生成プロセスをガイドするために使用できるguiderオブジェクトを生成します。このノードは、制御された生成に必要な基本的なガイダンス機能を提供します。

## 入力

| パラメータ | 説明 | データ型 | 必須 | 範囲 |
| --- | --- | --- | --- | --- |
| `モデル` | ガイダンスに使用するモデル | MODEL | はい | - |
| `コンディショニング` | 生成プロセスをガイドするconditioningデータ | CONDITIONING | はい | - |

## 出力

| 出力名 | 説明 | データ型 |
| --- | --- | --- |
| `GUIDER` | サンプリングプロセス中に生成をガイドするために使用できるguiderオブジェクト | GUIDER |

> このドキュメントは AI によって生成されました。エラーを見つけた場合や改善のご提案がある場合は、ぜひ貢献してください！ [GitHub で編集](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BasicGuider/ja.md)

---
**Source fingerprint (SHA-256):** `8ea6b56be58ae99baaf13a04c4fadbf8ad921801d8f2ce2aecce768cc34a3b20`
