# Bria 提高分辨率

Bria Increase Resolution 使用 Bria 的图像放大服务将输入图像放大 2 倍或 4 倍，同时保留原始内容。此节点会上传图像，将其提交到 Bria 服务进行处理，等待结果，并返回放大后的图像。

## 输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `图像` | 要放大的输入图像。 | IMAGE | 是 | 单张图像 |
| `desired_increase` | 分辨率倍数。输出每边必须不超过 8192 像素。 | COMBO | 是 | "2"<br>"4" |
| `auto_downscale` | 当输出将超过限制时，自动降低倍数；如果这仍然不够，则缩小输入图像。（默认：False） | BOOLEAN | 是 | True<br>False |
| `内容审核` | 审核设置。设置为 "true" 时，启用 `visual_input_moderation` 和 `visual_output_moderation` 子选项，二者默认均为 False。 | DYNAMIC_COMBO | 是 | "false"<br>"true" |

注意：
- 当 `moderation` 设置为 "true" 时，子选项 `visual_input_moderation` 和 `visual_output_moderation` 将可用，二者默认均为 False。它们控制输入图像和输出图像内容的审核。
- 此节点强制输出每边最大为 8192 像素。如果所选倍数会超过此限制且 `auto_downscale` 已禁用，则会引发错误。启用 `auto_downscale` 后，节点可以自动使用较低的倍数，或改为对输入图像进行缩小。
- Bria 会先将输入图像的短边放大到至少 224 像素，然后再进行放大。过于狭长的图像可能会触发错误，要求将其裁剪为更接近正方形的形状。

## 输出

| 输出名称 | 描述 | 数据类型 |
|-------------|-------------|-----------|
| `IMAGE` | Bria 服务返回的放大后的图像。 | IMAGE |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaIncreaseResolution/zh.md)

---
**Source fingerprint (SHA-256):** `6db9bf6c0d8a79903893b352658d3a8e02f67d375f3d604e9ab2a69624142885`
