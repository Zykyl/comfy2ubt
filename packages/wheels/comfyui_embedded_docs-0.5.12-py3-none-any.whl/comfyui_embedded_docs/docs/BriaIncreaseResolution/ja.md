# Bria 解像度を上げる

Bria Increase Resolution は、Bria の画像アップスケーリングサービスを使用して入力画像を 2 倍または 4 倍に拡大し、元のコンテンツを保持します。このノードは画像をアップロードし、Bria サービスでの処理を送信し、結果を待機して、アップスケールされた画像を返します。

## 入力

| パラメータ | 説明 | データ型 | 必須 | 範囲 |
|-----------|-------------|-----------|----------|-------|
| `画像` | アップスケールする入力画像。 | IMAGE | はい | 単一画像 |
| `desired_increase` | 解像度の倍率。出力は各辺 8192 ピクセル以内に収まる必要があります。 | COMBO | はい | "2"<br>"4" |
| `auto_downscale` | 出力が制限を超える場合に、倍率を自動的に下げ、それでも不十分な場合は入力画像をダウンスケールします。（デフォルト: False） | BOOLEAN | はい | True<br>False |
| `モデレーション` | モデレーション設定。"true" に設定すると、サブオプション `visual_input_moderation` と `visual_output_moderation` が有効になり、どちらもデフォルトは False です。 | DYNAMIC_COMBO | はい | "false"<br>"true" |

注記:
- `moderation` が "true" に設定されている場合、サブオプション `visual_input_moderation` と `visual_output_moderation` が使用可能になり、どちらもデフォルトは False です。これらは入力画像と出力画像のコンテンツのモデレーションを制御します。
- このノードは、出力の最大辺を 8192 ピクセルに制限します。選択した倍率がこの制限を超え、`auto_downscale` が無効な場合、エラーが発生します。`auto_downscale` を有効にすると、ノードは自動的に低い倍率を使用するか、代わりに入力画像をダウンスケールできます。
- Bria はアップスケーリングの前に、入力画像の短辺を少なくとも 224 ピクセルに拡大します。細長すぎる画像は、より正方形に近い形にトリミングするよう求めるエラーを引き起こす場合があります。

## 出力

| 出力名 | 説明 | データ型 |
|-------------|-------------|-----------|
| `IMAGE` | Bria サービスから返されたアップスケール済み画像。 | IMAGE |

> このドキュメントは AI によって生成されました。エラーを見つけた場合や改善のご提案がある場合は、ぜひ貢献してください！ [GitHub で編集](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaIncreaseResolution/ja.md)

---
**Source fingerprint (SHA-256):** `6db9bf6c0d8a79903893b352658d3a8e02f67d375f3d604e9ab2a69624142885`
