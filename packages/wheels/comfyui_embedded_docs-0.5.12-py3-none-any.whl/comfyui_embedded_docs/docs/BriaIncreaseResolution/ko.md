# Bria 해상도 높이기

Bria Increase Resolution은 Bria의 이미지 업스케일링 서비스를 사용하여 원본 콘텐츠를 보존하면서 입력 이미지를 2배 또는 4배로 업스케일합니다. 이 노드는 이미지를 업로드하고, Bria 서비스에서 처리하도록 제출한 뒤, 결과를 기다렸다가 업스케일된 이미지를 반환합니다.

## 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 | 범위 |
|-----------|-------------|-----------|----------|-------|
| `이미지` | 업스케일할 입력 이미지입니다. | IMAGE | 예 | 단일 이미지 |
| `desired_increase` | 해상도 배율입니다. 출력은 각 변이 8192픽셀 이내에 들어와야 합니다. | COMBO | 예 | "2"<br>"4" |
| `auto_downscale` | 출력이 제한을 초과하게 될 때 배율을 자동으로 낮추고, 그래도 충분하지 않으면 입력 이미지를 다운스케일합니다. (기본값: False) | BOOLEAN | 예 | True<br>False |
| `콘텐츠 검토` | 검열 설정입니다. "true"로 설정하면 `visual_input_moderation` 및 `visual_output_moderation` 하위 옵션이 활성화되며, 둘 다 기본값은 False입니다. | DYNAMIC_COMBO | 예 | "false"<br>"true" |

참고:
- `moderation`이 "true"로 설정되면 하위 옵션 `visual_input_moderation` 및 `visual_output_moderation`을 사용할 수 있으며, 둘 다 기본값은 False입니다. 이들은 입력 이미지 및 출력 이미지 콘텐츠의 검열을 제어합니다.
- 이 노드는 최대 출력 변 길이를 8192픽셀로 제한합니다. 선택한 배율이 이 제한을 초과하고 `auto_downscale`이 비활성화되어 있으면 오류가 발생합니다. `auto_downscale`을 활성화하면 노드가 자동으로 더 낮은 배율을 사용하거나 대신 입력 이미지를 다운스케일할 수 있습니다.
- Bria는 업스케일 전에 입력 이미지의 짧은 변을 먼저 최소 224픽셀까지 확대합니다. 지나치게 길쭉한 이미지는 더 정사각형에 가까운 형태로 자르라는 오류를 발생시킬 수 있습니다.

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
|-------------|-------------|-----------|
| `IMAGE` | Bria 서비스에서 반환된 업스케일된 이미지입니다. | IMAGE |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaIncreaseResolution/ko.md)

---
**Source fingerprint (SHA-256):** `6db9bf6c0d8a79903893b352658d3a8e02f67d375f3d604e9ab2a69624142885`
