# Bria Increase Resolution

Bria Increase Resolution upscales an input image by 2x or 4x using Bria's image upscaling service while preserving the original content. The node uploads the image, submits it for processing on the Bria service, waits for the result, and returns the upscaled image.

## Inputs

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `image` | The input image to upscale. | IMAGE | Yes | Single image |
| `desired_increase` | Resolution multiplier. The output must fit within 8192 pixels on each side. | COMBO | Yes | "2"<br>"4" |
| `auto_downscale` | Automatically lower the multiplier, and downscale the input image if that is still not enough, when the output would exceed the limit. (default: False) | BOOLEAN | Yes | True<br>False |
| `moderation` | Moderation settings. When set to "true", enables the `visual_input_moderation` and `visual_output_moderation` sub-options, both defaulting to False. | DYNAMIC_COMBO | Yes | "false"<br>"true" |

Notes:
- When `moderation` is set to "true", the sub-options `visual_input_moderation` and `visual_output_moderation` become available, both defaulting to False. They control moderation of the input image and the output image content.
- The node enforces a maximum output side of 8192 pixels. If the selected multiplier would exceed this limit and `auto_downscale` is disabled, an error is raised. Enabling `auto_downscale` allows the node to automatically use a lower multiplier or downscale the input image instead.
- Bria first enlarges the short side of the input image to at least 224 pixels before upscaling. Images that are too elongated may trigger an error asking to crop them to a squarer shape.

## Outputs

| Output Name | Description | Data Type |
|-------------|-------------|-----------|
| `IMAGE` | The upscaled image returned by the Bria service. | IMAGE |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaIncreaseResolution/en.md)

---
**Source fingerprint (SHA-256):** `6db9bf6c0d8a79903893b352658d3a8e02f67d375f3d604e9ab2a69624142885`
