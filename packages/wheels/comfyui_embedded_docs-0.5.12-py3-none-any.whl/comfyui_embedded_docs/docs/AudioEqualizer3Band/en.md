# Audio Equalizer (3-Band)

The Audio Equalizer (3-Band) node allows you to adjust the bass, mid, and treble frequencies of an audio waveform. It applies three separate filters: a low shelf for bass, a peaking filter for mids, and a high shelf for treble. Each band can be independently controlled with gain, frequency, and bandwidth settings.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `audio` | The input audio data containing the waveform and sample rate. | AUDIO | Yes | - |
| `low_gain_dB` | Gain for Low frequencies (Bass). Positive values boost, negative values cut. (default: 0.0) | FLOAT | No | -24.0 to 24.0 |
| `low_freq` | Cutoff frequency for Low shelf filter in Hertz (Hz). (default: 100) | INT | No | 20 to 500 |
| `mid_gain_dB` | Gain for Mid frequencies. Positive values boost, negative values cut. (default: 0.0) | FLOAT | No | -24.0 to 24.0 |
| `mid_freq` | Center frequency for the Mid peaking filter in Hertz (Hz). (default: 1000) | INT | No | 200 to 4000 |
| `mid_q` | Q factor (bandwidth) for the Mid peaking filter. Lower values create a wider band, higher values create a narrower band. (default: 0.707) | FLOAT | No | 0.1 to 10.0 |
| `high_gain_dB` | Gain for High frequencies (Treble). Positive values boost, negative values cut. (default: 0.0) | FLOAT | No | -24.0 to 24.0 |
| `high_freq` | Cutoff frequency for High shelf filter in Hertz (Hz). (default: 5000) | INT | No | 1000 to 15000 |

**Note:** The `low_gain_dB`, `mid_gain_dB`, and `high_gain_dB` parameters are only applied when their value is not zero. If a gain is set to 0.0, the corresponding filter stage is skipped.

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `audio` | The processed audio data with the equalization applied, containing the modified waveform and the original sample rate. | AUDIO |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioEqualizer3Band/en.md)

---
**Source fingerprint (SHA-256):** `be3a0981d8285885cb465e82717c3f56c9d301d55708962f9a9dd5b2c400ec81`
