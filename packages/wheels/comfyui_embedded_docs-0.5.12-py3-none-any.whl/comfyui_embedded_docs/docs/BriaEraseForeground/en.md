# BriaEraseForeground

This node removes the foreground of an image with Bria and generates a new background in its place. Everything Bria identifies as foreground is removed, not only people, and the untouched pixels are preserved. The result is re-rendered at a standard size close to 1 megapixel.

This is a paid API node that runs on Bria's service, so your Comfy API credentials are used for each run.

## Inputs

### Common Inputs

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `image` | The image whose foreground is removed and replaced with a generated background. Only the color channels are sent; any alpha channel is discarded before upload. | IMAGE | Yes | - |
| `moderation` | Moderation settings. Select `"false"` to send the image without moderation flags, or `"true"` to reveal the content-moderation toggles below. Default: `"false"`. | DYNAMIC_COMBO | Yes | `"false"`<br>`"true"` |

### `"false"` Inputs

No additional inputs. The request is sent without content-moderation flags.

### `"true"` Inputs

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `visual_input_moderation` | Enables content moderation on the input image. Default: false. | BOOLEAN | Yes | true<br>false |
| `visual_output_moderation` | Enables content moderation on the generated output image. Default: false. | BOOLEAN | Yes | true<br>false |

### Notes

- The output is re-rendered at a standard size close to 1 megapixel, so the returned image may differ in dimensions from the input.
- This node is a paid API node; each run costs approximately 0.0572 USD.

## Outputs

| Output Name | Description | Data Type |
|-------------|-------------|-----------|
| `IMAGE` | The input image with its foreground erased and a newly generated background in its place. | IMAGE |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaEraseForeground/en.md)

---
**Source fingerprint (SHA-256):** `4d8c3c5eed97c648b1191ec41931c97caa17e98a8edd1c054ed63e80cc671b05`
