# BriaEraseForeground

此节点使用 Bria 移除图像的前景，并在原位置生成新的背景。Bria 识别为前景的所有内容都会被移除，而不仅仅是人物，未触及的像素会保留。结果会以接近 1 百万像素的标准尺寸重新渲染。

这是一个付费 API 节点，运行在 Bria 的服务上，因此每次运行都会使用你的 Comfy API 凭据。

## 输入

### 通用输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `图像` | 要移除前景并替换为生成背景的图像。仅发送颜色通道；上传前会丢弃任何 alpha 通道。 | IMAGE | 是 | - |
| `内容审核` | 审核设置。选择 `"false"` 可在不发送审核标志的情况下发送图像，或选择 `"true"` 以显示下方的内容审核开关。默认：`"false"`。 | DYNAMIC_COMBO | 是 | `"false"`<br>`"true"` |

### `"false"` 输入

没有额外输入。请求将在不包含内容审核标志的情况下发送。

### `"true"` 输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `visual_input_moderation` | 启用对输入图像的内容审核。默认：false。 | BOOLEAN | 是 | true<br>false |
| `visual_output_moderation` | 启用对生成输出图像的内容审核。默认：false。 | BOOLEAN | 是 | true<br>false |

### 说明

- 输出会以接近 1 百万像素的标准尺寸重新渲染，因此返回的图像尺寸可能与输入不同。
- 此节点是付费 API 节点；每次运行费用约为 0.0572 USD。

## 输出

| 输出名称 | 描述 | 数据类型 |
|-------------|-------------|-----------|
| `IMAGE` | 输入图像，其前景已被擦除，并在原位置生成了新的背景。 | IMAGE |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaEraseForeground/zh.md)

---
**Source fingerprint (SHA-256):** `4d8c3c5eed97c648b1191ec41931c97caa17e98a8edd1c054ed63e80cc671b05`
