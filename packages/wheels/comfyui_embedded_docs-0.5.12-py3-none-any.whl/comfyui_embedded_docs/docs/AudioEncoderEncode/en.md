# AudioEncoderEncode

The AudioEncoderEncode node converts audio into an encoded representation using an audio encoder model. It takes an audio encoder and an audio input, then extracts the waveform and sample rate from the audio and passes them to the encoder to produce an encoded output.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `audio_encoder` | The audio encoder model used to process the audio input | AUDIO_ENCODER | Yes | - |
| `audio` | The audio data containing the waveform and sample rate information | AUDIO | Yes | - |

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `output` | The encoded audio representation produced by the audio encoder | AUDIO_ENCODER_OUTPUT |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioEncoderEncode/en.md)

---
**Source fingerprint (SHA-256):** `85f77152ccc1e3f4687e2b655283e69e03d90b862d6a676dcb89ea973dd70a63`
