# 音频编码器编码

AudioEncoderEncode 节点使用音频编码器模型将音频转换为编码表示。它接收音频编码器和音频输入，然后从音频中提取波形和采样率，并将它们传递给编码器以生成编码输出。

## 输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
| --- | --- | --- | --- | --- |
| `音频编码器` | 用于处理音频输入的音频编码器模型 | AUDIO_ENCODER | 是 | - |
| `音频` | 包含波形和采样率信息的音频数据 | AUDIO | 是 | - |

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `output` | 音频编码器生成的编码音频表示 | AUDIO_ENCODER_OUTPUT |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioEncoderEncode/zh.md)

---
**Source fingerprint (SHA-256):** `85f77152ccc1e3f4687e2b655283e69e03d90b862d6a676dcb89ea973dd70a63`
