# Concatenate Audio

The AudioConcat node combines two audio inputs by joining them together. It takes two audio inputs and connects them in the order you specify, either placing the second audio before or after the first audio. The node automatically handles different audio formats by converting mono audio to stereo and matching sample rates between the two inputs.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `audio1` | The first audio input to be concatenated | AUDIO | Yes | - |
| `audio2` | The second audio input to be concatenated | AUDIO | Yes | - |
| `direction` | Whether to append audio2 after or before audio1 (default: "after") | COMBO | Yes | `"after"`<br>`"before"` |

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `AUDIO` | The combined audio containing both input audio files joined together | AUDIO |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioConcat/en.md)

---
**Source fingerprint (SHA-256):** `faccc3d42e9c6927deadb7d5f7fe9e5bbbf08e4e9a3d636f42a2b9f995eec8c1`
