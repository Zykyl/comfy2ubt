# 오디오 연결

다음은 요청하신 조건에 따라 번역한 결과입니다.

---

AudioConcat 노드는 두 개의 오디오 입력을 결합하여 하나로 이어 붙입니다. 두 개의 오디오 입력을 받아 지정한 순서대로 연결하며, 두 번째 오디오를 첫 번째 오디오 앞이나 뒤에 배치할 수 있습니다. 이 노드는 모노 오디오를 스테레오로 변환하고 두 입력 간의 샘플 레이트를 일치시키는 방식으로 서로 다른 오디오 형식을 자동으로 처리합니다.

## 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 여부 | 범위 |
| --- | --- | --- | --- | --- |
| `audio1` | 연결할 첫 번째 오디오 입력입니다. | AUDIO | 예 | - |
| `audio2` | 연결할 두 번째 오디오 입력입니다. | AUDIO | 예 | - |
| `direction` | audio2를 audio1 뒤에 추가할지 앞에 추가할지 선택합니다. (기본값: "after") | COMBO | 예 | `"after"`<br>`"before"` |

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
| --- | --- | --- |
| `AUDIO` | 두 입력 오디오 파일이 결합된 최종 오디오입니다. | AUDIO |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioConcat/ko.md)

---
**Source fingerprint (SHA-256):** `b54046e29761cf27bc5b1c065dac87846613afc0b5cbb296632628bf7d4527b7`
