# 音频拼接

AudioConcat 节点通过拼接两个音频输入来合并它们。该节点接收两个音频输入，并按照您指定的顺序连接它们，可以将第二个音频放置在第一个音频之前或之后。节点会自动处理不同的音频格式，将单声道音频转换为立体声，并匹配两个输入之间的采样率。

## 输入

| 参数 | 描述 | 数据类型 | 是否必填 | 取值范围 |
| --- | --- | --- | --- | --- |
| `音频1` | 要拼接的第一个音频输入 | AUDIO | 是 | - |
| `音频2` | 要拼接的第二个音频输入 | AUDIO | 是 | - |
| `方向` | 将 audio2 附加到 audio1 之后或之前（默认值："after"） | COMBO | 是 | `"after"`<br>`"before"` |

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `AUDIO` | 包含两个输入音频文件拼接后的合并音频 | AUDIO |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioConcat/zh.md)

---
**Source fingerprint (SHA-256):** `b54046e29761cf27bc5b1c065dac87846613afc0b5cbb296632628bf7d4527b7`
