# Bake Normal Map from Mesh

This node bakes a tangent-space normal map from a high-poly mesh onto a low-poly mesh's UV layout, capturing surface detail that was lost during decimation. Connect the UV-unwrapped low-poly mesh and the high-poly mesh it came from, and the node outputs an image ready for the `normal_map` input of Apply Texture To Mesh.

## Inputs

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `low_poly` | The UV-unwrapped low-poly mesh that receives the baked detail. Must have existing UVs; the node never unwraps. | MESH | Yes | — |
| `high_poly` | The high-poly mesh whose surface detail is baked into the low-poly's UV layout. | MESH | Yes | — |
| `resolution` | Edge length in pixels of the square output normal map (default: 1024). | INT | Yes | 64 to 8192 (step 64) |
| `cage_distance` | Surface search band, as a fraction of the bounding box diagonal. Raise for wrong/missing patches under heavy decimation; lower if it grabs across gaps. Default: 0.05. | FLOAT | Yes | 0.001 to 0.5 (step 0.001) |
| `ignore_backfaces` | Skip high-poly surfaces facing away from the texel, so crevices/enclosed spaces don't grab the opposite wall. Disable only if the high-poly winding is inconsistent. Default: true. | BOOLEAN | Yes | true / false |

Note: `low_poly` must have UV coordinates. If it has none, the node raises an error because it bakes onto the existing UV layout and does not unwrap the mesh. When `low_poly` is a batch, each item is baked in order; if `high_poly` contains only one item, that item is reused for every batch item. Empty meshes in the batch are skipped with a warning and produce a flat mid-gray (0.5) normal map. If the low-poly UVs spill outside the [0,1] range, they are uniformly fitted into [0,1] (with a warning when the layout looks tiled/UDIM), so the bake and Apply Texture To Mesh use the same UVs.

## Outputs

| Output Name | Description | Data Type |
|-------------|-------------|-----------|
| `normal_map` | The baked tangent-space normal map (glTF/OpenGL +Y convention) as a square resolution × resolution RGB image with values in [0,1]. Connect it to the `normal_map` input of Apply Texture To Mesh. | IMAGE |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BakeNormalMapFromMesh/en.md)

---
**Source fingerprint (SHA-256):** `29df10014b5998b741d71db21d0c982d7bca85ad966a720063af15062e203322`
