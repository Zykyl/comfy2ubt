# 从网格烘焙法线贴图

此节点将高多边形网格的切线空间法线贴图烘焙到低多边形网格的 UV 布局上，以捕捉在简化过程中丢失的表面细节。连接已展开 UV 的低多边形网格及其来源的高多边形网格，节点会输出一张可直接用于 Apply Texture To Mesh 的 `normal_map` 输入的图像。

## 输入

| 参数 | 描述 | 数据类型 | 必填 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `low_poly` | 接收烘焙细节的已展开 UV 的低多边形网格。必须已有 UV；此节点从不执行展开。 | MESH | 是 | — |
| `high_poly` | 其表面细节会被烘焙到低多边形 UV 布局中的高多边形网格。 | MESH | 是 | — |
| `resolution` | 方形输出法线贴图的边长，单位为像素（默认：1024）。 | INT | 是 | 64 到 8192 （步长：64） |
| `cage_distance` | 表面搜索带，以包围盒对角线长度的比例表示。在重度简化下出现错误/缺失贴片时调高；如果它会跨间隙抓取表面则调低。默认：0.05。 | FLOAT | 是 | 0.001 到 0.5 （步长：0.001） |
| `ignore_backfaces` | 跳过背向纹素的高多边形表面，这样裂缝/封闭空间就不会抓取到对面的壁面。仅当高多边形绕序不一致时才禁用。默认：true。 | BOOLEAN | 是 | true / false |

注意：`low_poly` 必须具有 UV 坐标。如果没有，节点会报错，因为它会烘焙到现有 UV 布局上，而不会展开网格。当 `low_poly` 是批次时，会按顺序烘焙每一项；如果 `high_poly` 只包含一项，则该 item 会复用于每个批次项。批次中的空网格会被跳过并给出警告，同时生成一张平坦的中灰色（0.5）法线贴图。如果低多边形 UV 超出 [0,1] 范围，它们会被统一拟合到 [0,1]（当布局看起来是平铺/UDIM 时会给出警告），因此烘焙和 Apply Texture To Mesh 使用相同的 UV。

## 输出

| 输出名称 | 描述 | 数据类型 |
|-------------|-------------|-----------|
| `normal_map` | 烘焙后的切线空间法线贴图（glTF/OpenGL +Y 约定），为 `resolution` × `resolution` 的方形 RGB 图像，值在 [0,1] 范围内。将其连接到 Apply Texture To Mesh 的 `normal_map` 输入。 | IMAGE |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BakeNormalMapFromMesh/zh.md)

---
**Source fingerprint (SHA-256):** `29df10014b5998b741d71db21d0c982d7bca85ad966a720063af15062e203322`
