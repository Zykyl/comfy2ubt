# BriaRelight

이 노드는 Bria를 사용하여 이미지의 조명 분위기와 방향을 변경합니다. Bria가 이미지를 다시 렌더링하므로 결과는 입력과 픽셀 단위로 정렬되지 않습니다. 전체 프레임은 약 1메가픽셀 크기로 재생성됩니다.

## 입력

### 공통 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 | 범위 |
|-----------|-------------|-----------|----------|-------|
| `이미지` | 조명을 변경할 이미지입니다. 이미지를 업로드하기 전에 모든 알파 채널이 제거됩니다. | IMAGE | 예 | - |
| `light_type` | 적용할 조명 분위기입니다. | COMBO | 예 | `"midday"`<br>`"blue hour light"`<br>`"low-angle sunlight"`<br>`"sunrise light"`<br>`"spotlight on subject"`<br>`"overcast light"`<br>`"soft overcast daylight lighting"`<br>`"cloud-filtered lighting"`<br>`"fog-diffused lighting"`<br>`"moonlight lighting"`<br>`"starlight nighttime"`<br>`"soft bokeh lighting"`<br>`"harsh studio lighting"` |
| `light_direction` | 빛이 들어오는 방향입니다. midday, spotlight on subject, harsh studio lighting과 같은 하드 라이트 분위기가 이 설정에 가장 민감하게 반응합니다. | COMBO | 예 | `"front"`<br>`"side"`<br>`"bottom"`<br>`"top-down"` |
| `검토` | 모데레이션 설정입니다. `"true"`를 선택하면 모데레이션 옵션이 표시되고, `"false"`를 선택하면 해당 옵션 없이 실행됩니다. | DYNAMIC_COMBO | 예 | `"false"`<br>`"true"` |

### 모데레이션 입력

이 옵션들은 `moderation`이 `"true"`로 설정된 경우 나타납니다.

| 매개변수 | 설명 | 데이터 타입 | 필수 | 범위 |
|-----------|-------------|-----------|----------|-------|
| `visual_input_moderation` | 입력 이미지에 대한 콘텐츠 모데레이션을 활성화합니다. 기본값: false. | BOOLEAN | 아니요 | `true`<br>`false` |
| `visual_output_moderation` | 생성된 출력 이미지에 대한 콘텐츠 모데레이션을 활성화합니다. 기본값: false. | BOOLEAN | 아니요 | `true`<br>`false` |

참고: Bria는 전체 프레임을 약 1메가픽셀로 다시 렌더링하므로 결과는 입력과 픽셀 단위로 정렬되지 않습니다.

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
|-------------|-------------|-----------|
| `image` | Bria가 반환한 조명이 변경된 이미지입니다. | IMAGE |
| `structured_prompt` | 편집된 이미지의 구조화된 설명으로, Bria FIBO Image Edit를 사용한 후속 편집에 사용됩니다. | STRING |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaRelight/ko.md)

---
**Source fingerprint (SHA-256):** `21fbe2186c99a7e8d99d5659ac25c3ab1a757492916dba4135487d4b293cb4f6`
