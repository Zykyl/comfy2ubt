# BriaRelight

This node changes the lighting atmosphere and direction of an image using Bria. The image is re-rendered by Bria, so the result is not pixel-aligned with the input; the whole frame is regenerated at about 1 megapixel.

## Inputs

### Common Inputs

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `image` | The image whose lighting is changed. Any alpha channel is dropped before the image is uploaded. | IMAGE | Yes | - |
| `light_type` | Lighting atmosphere to apply. | COMBO | Yes | `"midday"`<br>`"blue hour light"`<br>`"low-angle sunlight"`<br>`"sunrise light"`<br>`"spotlight on subject"`<br>`"overcast light"`<br>`"soft overcast daylight lighting"`<br>`"cloud-filtered lighting"`<br>`"fog-diffused lighting"`<br>`"moonlight lighting"`<br>`"starlight nighttime"`<br>`"soft bokeh lighting"`<br>`"harsh studio lighting"` |
| `light_direction` | Where the light comes from. Hard-light atmospheres such as midday, spotlight on subject and harsh studio lighting react to it the most. | COMBO | Yes | `"front"`<br>`"side"`<br>`"bottom"`<br>`"top-down"` |
| `moderation` | Moderation settings. Select `"true"` to reveal the moderation options, or `"false"` to run without them. | DYNAMIC_COMBO | Yes | `"false"`<br>`"true"` |

### Moderation Inputs

These options appear when `moderation` is set to `"true"`.

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `visual_input_moderation` | Enables content moderation on the input image. Default: false. | BOOLEAN | No | `true`<br>`false` |
| `visual_output_moderation` | Enables content moderation on the generated output image. Default: false. | BOOLEAN | No | `true`<br>`false` |

Note: Bria re-renders the whole frame at about 1 megapixel, so the result is not pixel-aligned with the input.

## Outputs

| Output Name | Description | Data Type |
|-------------|-------------|-----------|
| `image` | The relit image returned by Bria. | IMAGE |
| `structured_prompt` | Structured description of the edited image, for a follow-up edit with Bria FIBO Image Edit. | STRING |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaRelight/en.md)

---
**Source fingerprint (SHA-256):** `21fbe2186c99a7e8d99d5659ac25c3ab1a757492916dba4135487d4b293cb4f6`
