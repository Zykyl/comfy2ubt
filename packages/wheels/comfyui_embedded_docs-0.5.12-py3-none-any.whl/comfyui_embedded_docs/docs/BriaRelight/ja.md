# BriaRelight

このノードは Bria を使用して、画像のライティングの雰囲気と方向を変更します。画像は Bria によって再レンダリングされるため、結果は入力とピクセル単位で位置合わせされません。フレーム全体が約 1 メガピクセルで再生成されます。

## 入力

### 共通入力

| パラメータ | 説明 | データ型 | 必須 | 範囲 |
|-----------|-------------|-----------|----------|-------|
| `画像` | ライティングを変更する画像。画像がアップロードされる前に、アルファチャンネルは破棄されます。 | IMAGE | はい | - |
| `light_type` | 適用するライティングの雰囲気。 | COMBO | はい | `"midday"`<br>`"blue hour light"`<br>`"low-angle sunlight"`<br>`"sunrise light"`<br>`"spotlight on subject"`<br>`"overcast light"`<br>`"soft overcast daylight lighting"`<br>`"cloud-filtered lighting"`<br>`"fog-diffused lighting"`<br>`"moonlight lighting"`<br>`"starlight nighttime"`<br>`"soft bokeh lighting"`<br>`"harsh studio lighting"` |
| `light_direction` | 光がどこから来るか。midday、spotlight on subject、harsh studio lighting などのハードライトの雰囲気は、これに最も反応します。 | COMBO | はい | `"front"`<br>`"side"`<br>`"bottom"`<br>`"top-down"` |
| `モデレーション` | モデレーション設定。`"true"` を選択するとモデレーションオプションが表示され、`"false"` を選択するとそれらを使用せずに実行します。 | DYNAMIC_COMBO | はい | `"false"`<br>`"true"` |

### モデレーション入力

これらのオプションは、`moderation` が `"true"` に設定されている場合に表示されます。

| パラメータ | 説明 | データ型 | 必須 | 範囲 |
|-----------|-------------|-----------|----------|-------|
| `visual_input_moderation` | 入力画像に対するコンテンツモデレーションを有効にします。デフォルト: false。 | BOOLEAN | いいえ | `true`<br>`false` |
| `visual_output_moderation` | 生成された出力画像に対するコンテンツモデレーションを有効にします。デフォルト: false。 | BOOLEAN | いいえ | `true`<br>`false` |

注: Bria はフレーム全体を約 1 メガピクセルで再レンダリングするため、結果は入力とピクセル単位で位置合わせされません。

## 出力

| 出力名 | 説明 | データ型 |
|-------------|-------------|-----------|
| `image` | Bria によって返された再照明された画像。 | IMAGE |
| `structured_prompt` | Bria FIBO Image Edit での後続の編集に使用する、編集された画像の構造化された説明。 | STRING |

> このドキュメントは AI によって生成されました。エラーを見つけた場合や改善のご提案がある場合は、ぜひ貢献してください！ [GitHub で編集](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaRelight/ja.md)

---
**Source fingerprint (SHA-256):** `21fbe2186c99a7e8d99d5659ac25c3ab1a757492916dba4135487d4b293cb4f6`
