# Adaptive Projected Guidance

The APG (Adaptive Projected Guidance) node modifies the sampling process by adjusting how guidance is applied during diffusion. It separates the guidance vector into parallel and orthogonal components relative to the conditional output, allowing for more controlled image generation. The node provides parameters to scale the guidance, normalize its magnitude, and apply momentum for smoother transitions between diffusion steps.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `model` | The diffusion model to apply adaptive projected guidance to | MODEL | Yes | - |
| `eta` | Controls the scale of the parallel guidance vector. Default CFG behavior at a setting of 1 (default: 1.0). | FLOAT | No | -10.0 to 10.0 |
| `norm_threshold` | Normalize guidance vector to this value, normalization disabled at a setting of 0 (default: 5.0). | FLOAT | No | 0.0 to 50.0 |
| `momentum` | Controls a running average of guidance during diffusion, disabled at a setting of 0 (default: 0.0). | FLOAT | No | -5.0 to 1.0 |

Note: When the noise level (`sigma`) increases during sampling, the momentum running average resets to zero. If the model provides only a single conditioning output (no separate unconditional conditioning), the guidance adjustment is skipped and the conditioning is left unchanged.

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `model` | Returns the modified model with adaptive projected guidance applied to its sampling process | MODEL |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/APG/en.md)

---
**Source fingerprint (SHA-256):** `df0c76aee28479d49c4e471e54d1d32082adc6921a6a50b506675144a79e018a`
