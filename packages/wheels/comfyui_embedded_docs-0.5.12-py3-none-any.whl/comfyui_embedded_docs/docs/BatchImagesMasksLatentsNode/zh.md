# BatchImagesMasksLatentsNode

批量图像/遮罩/潜空间节点将多个相同类型的输入合并为单个批次。它会自动检测输入是图像、遮罩还是潜空间表示，并使用相应的批处理方法。这对于准备多个项目以供接受批量输入的节点处理非常有用。

## 输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
| --- | --- | --- | --- | --- |
| `inputs` | 要合并为批次的动态输入列表。您可以添加 1 到 50 个项目。所有项目必须为相同类型（全部为图像、全部为遮罩或全部为潜空间）。 | IMAGE、MASK 或 LATENT | 是 | 1 到 50 个输入 |

**注意：** 节点会根据 `inputs` 列表中的第一个项目自动确定数据类型（IMAGE、MASK 或 LATENT）。所有后续项目必须与此类型匹配。如果尝试混合不同的数据类型，节点将失败。

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `output` | 单个批次输出。数据类型与输入类型匹配（批量 IMAGE、批量 MASK 或批量 LATENT）。 | IMAGE、MASK 或 LATENT |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BatchImagesMasksLatentsNode/zh.md)

---
**Source fingerprint (SHA-256):** `6f3037bc00fd8526f42ad2d79a0f27434f58bd6dd0338a585cc707a771ac0989`
