# BatchImagesMasksLatentsNode

배치 이미지/마스크/잠재 표현 노드는 동일한 유형의 여러 입력을 단일 배치로 결합합니다. 입력이 이미지, 마스크 또는 잠재 표현인지 자동으로 감지하여 적절한 배치 방법을 사용합니다. 이는 배치 입력을 허용하는 노드에서 처리할 여러 항목을 준비할 때 유용합니다.

## 입력

| 매개변수 | 설명 | 데이터 유형 | 필수 여부 | 범위 |
| --- | --- | --- | --- | --- |
| `inputs` | 배치로 결합할 동적 입력 목록입니다. 1~50개 항목을 추가할 수 있습니다. 모든 항목은 동일한 유형(모두 이미지, 모두 마스크, 또는 모두 잠재 표현)이어야 합니다. | IMAGE, MASK 또는 LATENT | 예 | 1~50개 입력 |

**참고:** 이 노드는 `inputs` 목록의 첫 번째 항목을 기준으로 데이터 유형(IMAGE, MASK 또는 LATENT)을 자동으로 결정합니다. 이후 모든 항목은 이 유형과 일치해야 합니다. 서로 다른 데이터 유형을 혼합하려고 하면 노드가 실패합니다.

## 출력

| 출력 이름 | 설명 | 데이터 유형 |
| --- | --- | --- |
| `output` | 단일 배치 출력입니다. 데이터 유형은 입력 유형(배치 IMAGE, 배치 MASK 또는 배치 LATENT)과 일치합니다. | IMAGE, MASK 또는 LATENT |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BatchImagesMasksLatentsNode/ko.md)

---
**Source fingerprint (SHA-256):** `6f3037bc00fd8526f42ad2d79a0f27434f58bd6dd0338a585cc707a771ac0989`
