# BatchImagesMasksLatentsNode

The Batch Images/Masks/Latents node combines multiple inputs of the same type into a single batch. It automatically detects whether the inputs are images, masks, or latent representations and uses the appropriate batching method. This is useful for preparing multiple items for processing by nodes that accept batched inputs.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `inputs` | A dynamic list of inputs to be combined into a batch. You can add between 1 and 50 items. All items must be of the same type (all images, all masks, or all latents). | IMAGE, MASK, or LATENT | Yes | 1 to 50 inputs |

**Note:** The node automatically determines the data type (IMAGE, MASK, or LATENT) based on the first item in the `inputs` list. All subsequent items must match this type. The node will fail if you try to mix different data types.

**Additional behavior based on input type:**
- **Images**: When batching images, the node pads images with fewer color channels to match the maximum channel count among all inputs (padding value is 1.0). It also resizes all images to match the dimensions of the first image using bilinear interpolation.
- **Masks**: When batching masks, the node resizes all masks to match the dimensions of the first mask using bilinear interpolation.
- **Latents**: When batching latents, the node reshapes all latent tensors to match the dimensions of the first latent's samples. It also combines the `batch_index` values from each latent, extending the list with sequential indices if a latent lacks a `batch_index`.

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `output` | A single batched output. The data type matches the input type (batched IMAGE, batched MASK, or batched LATENT). | IMAGE, MASK, or LATENT |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BatchImagesMasksLatentsNode/en.md)

---
**Source fingerprint (SHA-256):** `9f82b036c99577ebcda6de647c662def572ae1f01bd78dca1a0ab32f4698e09e`
