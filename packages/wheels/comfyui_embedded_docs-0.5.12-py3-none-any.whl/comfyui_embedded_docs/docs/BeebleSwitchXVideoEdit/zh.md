# Beeble SwitchX 视频编辑

使用 Beeble SwitchX 编辑视频。此节点可以切换场景中的任何内容（背景、光照、服装），同时保留原始主体的像素和运动。提供参考图像和/或文本提示来描述新的外观。

## ## 输入

| 参数 | 描述 | 数据类型 | 是否必需 | 范围 |
| --- | --- | --- | --- | --- |
| `视频` | 要编辑的输入视频。最多 240 帧，每帧最多约 277 万像素。 | VIDEO | 是 | 不适用 |
| `提示词` | 场景所需新外观的文本描述。 | STRING | 是 | 不适用 |
| `alpha_mode` | Alpha 遮罩模式。"fill"模式没有单独的遮罩，填充整个帧。"select"模式使用单个关键帧图像来定义要编辑的区域。"custom"模式使用完整的 Alpha 视频逐帧定义要编辑的区域。 | COMBO | 是 | `"fill"`<br>`"select"`<br>`"custom"` |
| `最大分辨率` | 输出视频的最大分辨率（默认值："1080p"）。 | COMBO | 是 | `"720p"`<br>`"1080p"` |
| `种子` | 用于可复现性的种子值。使用相同的种子和相同的输入将产生相同的结果。 | INT | 是 | 0 到 2147483647 |
| `参考图像` | 描述场景所需新外观的可选参考图像。 | IMAGE | 否 | 不适用 |

### Alpha 模式详情

`alpha_mode` 参数控制视频的哪些部分被编辑：

- **fill**：编辑整个视频帧。不生成单独的 Alpha 遮罩。
- **select**：您提供一个定义要编辑区域的单个关键帧图像。节点将使用此图像来确定要更改视频的哪些部分。
- **custom**：您提供一个完整的 Alpha 视频，逐帧定义要编辑的区域。这使您可以精确控制每帧的哪些部分被编辑。

使用 `select` 模式时，您必须提供 `alpha_keyframe` 图像。使用 `custom` 模式时，您必须提供 `alpha_mask` 视频。

## ## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `视频` | 应用了场景更改后的编辑视频。 | VIDEO |
| `alpha` | Beeble 使用的 Alpha 遮罩。对于没有单独遮罩的"fill"模式，此输出为空。 | VIDEO |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BeebleSwitchXVideoEdit/zh.md)

---
**Source fingerprint (SHA-256):** `e2d67b037863f024f42c97943ec0d2daf32b547b232a7dfedd6de398f4b7ba28`
