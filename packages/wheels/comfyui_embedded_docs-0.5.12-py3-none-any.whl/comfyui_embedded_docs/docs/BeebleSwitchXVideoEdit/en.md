# Beeble SwitchX Video Edit

Edit a video with Beeble SwitchX. This node can switch anything in the scene (background, lighting, costume) while preserving the original subject's pixels and motion. Provide a reference image and/or text prompt to describe the new look. Maximum 240 frames, maximum approximately 2.77 megapixels per frame.

## Inputs

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `video` | The input video to edit. | VIDEO | Yes | N/A |
| `prompt` | A text description of the desired new look for the scene. | STRING | Yes | N/A |
| `alpha_mode` | The alpha matte mode. "fill" mode has no separate matte and fills the entire frame. "select" mode uses a single keyframe image to define the area to edit. "custom" mode uses a full alpha video to define the area to edit frame by frame. | COMBO | Yes | `"fill"`<br>`"select"`<br>`"custom"` |
| `max_resolution` | The maximum resolution for the output video (default: "1080p"). | COMBO | Yes | `"720p"`<br>`"1080p"` |
| `seed` | A seed value for reproducibility. Using the same seed with the same inputs will produce the same result. | INT | Yes | 0 to 2147483647 |
| `reference_image` | An optional reference image that describes the desired new look for the scene. | IMAGE | No | N/A |

### Alpha Mode Details

The `alpha_mode` parameter controls which parts of the video are edited:

- **fill**: The entire video frame is edited. No separate alpha matte is produced.
- **select**: You provide a single keyframe image that defines the area to edit. The node will use this to determine which parts of the video to change.
- **custom**: You provide a full alpha video that defines the area to edit frame by frame. This gives you precise control over which parts of each frame are edited.

When using `select` mode, you must provide the `alpha_keyframe` image. When using `custom` mode, you must provide the `alpha_mask` video.

## Outputs

| Output Name | Description | Data Type |
|-------------|-------------|-----------|
| `video` | The edited video with the scene changes applied. | VIDEO |
| `alpha` | The alpha matte used by Beeble. This is empty for "fill" mode, which has no separate matte. | VIDEO |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BeebleSwitchXVideoEdit/en.md)

---
**Source fingerprint (SHA-256):** `a92e78e6a08ac01466d953562a250b812eb8b1a5fb37efce6fddd7aa1ef380a2`
