# BriaAddObject

このノードは、プレーンテキストで記述されたオブジェクトを Bria を使用して画像に挿入します。Bria はフレーム全体を約 1 メガピクセルで再レンダリングするため、結果は入力とピクセル単位で位置合わせされません。

## 入力

### 共通入力

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `画像` | 記述されたオブジェクトを追加する対象の画像です。画像がアップロードされる前に、アルファチャンネルは削除されます。 | IMAGE | はい | - |
| `指示` | 何をどこに追加するか（例：「テーブルの上に花の入った赤い花瓶を置く」）。空にすることはできません。デフォルト: ""（空文字列）。 | STRING | はい | - |
| `シード` | ここでは Bria は seed を受け取らず、呼び出しごとに編集を再生成するため、繰り返し実行すると結果が異なる場合があります。この値は送信されることはありません。これはこのノードのキャッシュキーを変更するだけであり、それ以外は同一のグラフがキャッシュされた結果を返す代わりに、編集を再実行するようにします。デフォルト: 42。 | INT | はい | 0 〜 2147483647 |
| `モデレーション` | モデレーション設定です。以下のモデレーションフラグを表示するには "true" を選択します。 | DYNAMIC_COMBO | はい | "false"<br>"true" |

### モデレーション有効時の入力

`moderation` が "true" に設定されている場合に使用できます。

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `visual_input_moderation` | 入力画像に対するコンテンツモデレーションを有効にします。デフォルト: False。 | BOOLEAN | いいえ | True / False |
| `visual_output_moderation` | 生成された出力画像に対するコンテンツモデレーションを有効にします。デフォルト: False。 | BOOLEAN | いいえ | True / False |

## 出力

| Output Name | Description | Data Type |
|-------------|-------------|-----------|
| `image` | 記述されたオブジェクトが追加された編集済み画像です。 | IMAGE |
| `structured_prompt` | 編集済み画像の構造化された説明です。Bria FIBO Image Edit での後続の編集に使用します。 | STRING |

> このドキュメントは AI によって生成されました。エラーを見つけた場合や改善のご提案がある場合は、ぜひ貢献してください！ [GitHub で編集](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaAddObject/ja.md)

---
**Source fingerprint (SHA-256):** `41c9a3e511763372d8dc8be9da4f70158e53d5156a88eb3c66f81149efdbd566`
