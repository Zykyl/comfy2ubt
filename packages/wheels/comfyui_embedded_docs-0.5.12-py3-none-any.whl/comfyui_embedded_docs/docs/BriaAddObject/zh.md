# BriaAddObject

此节点使用 Bria 将纯文本描述的对象插入图像中。Bria 会以约 1 百万像素重新渲染整个画面，因此结果不会与输入图像像素对齐。

## 输入

### 通用输入

| 参数 | 描述 | 数据类型 | 必填 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `图像` | 要添加所描述对象的图像。上传图像前会丢弃 alpha 通道。 | IMAGE | 是 | - |
| `指令` | 要添加什么以及在哪里添加，例如 'Place a red vase with flowers on the table'。不能为空。默认值：""（空字符串）。 | STRING | 是 | - |
| `种子` | Bria 在此处不接受种子，每次调用都会重新构想编辑，因此重复运行可能产生不同结果。该值从不会被发送：它只会改变此节点的缓存键，这样在其他方面完全相同的工作流图会再次运行编辑，而不是返回缓存结果。默认值：42。 | INT | 是 | 0 到 2147483647 |
| `内容审核` | 审核设置。选择 "true" 以显示下方的审核标志。 | DYNAMIC_COMBO | 是 | "false"<br>"true" |

### 启用审核时的输入

当 `moderation` 设置为 "true" 时可用。

| 参数 | 描述 | 数据类型 | 必填 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `visual_input_moderation` | 对输入图像启用内容审核。默认值：False。 | BOOLEAN | 否 | True / False |
| `visual_output_moderation` | 对生成的输出图像启用内容审核。默认值：False。 | BOOLEAN | 否 | True / False |

## 输出

| 输出名称 | 描述 | 数据类型 |
|-------------|-------------|-----------|
| `image` | 添加了所描述对象后的编辑图像。 | IMAGE |
| `structured_prompt` | 编辑图像的结构化描述，用于使用 Bria FIBO Image Edit 进行后续编辑。 | STRING |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaAddObject/zh.md)

---
**Source fingerprint (SHA-256):** `41c9a3e511763372d8dc8be9da4f70158e53d5156a88eb3c66f81149efdbd566`
