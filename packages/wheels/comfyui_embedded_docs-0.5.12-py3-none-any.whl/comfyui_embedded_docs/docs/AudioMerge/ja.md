# オーディオ結合

このドキュメントはAIによって生成されました。誤りや改善の提案がありましたら、ぜひご協力ください！[GitHubで編集する](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioMerge/en.md)

AudioMergeノードは、2つのオーディオトラックの波形を重ね合わせて結合します。両方のオーディオ入力のサンプルレートを自動的に一致させ、マージ前に長さを等しく調整します。このノードは、オーディオ信号を結合するためのいくつかの数学的手法を提供し、出力が許容可能な音量レベル内に収まるようにします。

## 入力

| パラメータ | 説明 | データ型 | 必須 | 範囲 |
| --- | --- | --- | --- | --- |
| `オーディオ1` | マージする最初のオーディオ入力 | AUDIO | はい | - |
| `オーディオ2` | マージする2番目のオーディオ入力 | AUDIO | はい | - |
| `結合方法` | オーディオ波形を結合するために使用する方法。 | COMBO | はい | `"add"`<br>`"mean"`<br>`"subtract"`<br>`"multiply"` |

## 出力

| 出力名 | 説明 | データ型 |
| --- | --- | --- |
| `AUDIO` | 結合された波形とサンプルレートを含む、マージ後のオーディオ出力 | AUDIO |

> このドキュメントは AI によって生成されました。エラーを見つけた場合や改善のご提案がある場合は、ぜひ貢献してください！ [GitHub で編集](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioMerge/ja.md)

---
**Source fingerprint (SHA-256):** `2a4a7da42835efd03cc67002e617a70c0514524a0ac0ed61d57e499c1283be95`
