# 音频合并

AudioMerge 节点通过叠加波形来合并两条音轨。它会自动匹配两个音频输入的采样率，并在合并前将它们的长度调整为相等。该节点提供了多种数学方法来组合音频信号，并确保输出保持在可接受的音量范围内。

## 输入

| 参数 | 描述 | 数据类型 | 是否必填 | 取值范围 |
| --- | --- | --- | --- | --- |
| `音频1` | 要合并的第一个音频输入 | AUDIO | 是 | - |
| `音频2` | 要合并的第二个音频输入 | AUDIO | 是 | - |
| `合并方法` | 用于组合音频波形的方法。 | COMBO | 是 | `"add"`<br>`"mean"`<br>`"subtract"`<br>`"multiply"` |

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `AUDIO` | 合并后的音频输出，包含组合后的波形和采样率 | AUDIO |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioMerge/zh.md)

---
**Source fingerprint (SHA-256):** `2a4a7da42835efd03cc67002e617a70c0514524a0ac0ed61d57e499c1283be95`
