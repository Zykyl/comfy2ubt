# 오디오 병합

AudioMerge 노드는 두 개의 오디오 트랙을 파형을 오버레이하여 결합합니다. 두 오디오 입력의 샘플 속도를 자동으로 일치시키고, 병합 전에 길이를 동일하게 조정합니다. 이 노드는 오디오 신호를 결합하기 위한 여러 수학적 방법을 제공하며, 출력이 허용 가능한 볼륨 수준 내에 유지되도록 보장합니다.

## 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 | 범위 |
| --- | --- | --- | --- | --- |
| `audio1` | 병합할 첫 번째 오디오 입력 | AUDIO | 예 | - |
| `audio2` | 병합할 두 번째 오디오 입력 | AUDIO | 예 | - |
| `merge_method` | 오디오 파형을 결합하는 데 사용되는 방법입니다. | COMBO | 예 | `"add"`<br>`"mean"`<br>`"subtract"`<br>`"multiply"` |

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
| --- | --- | --- |
| `AUDIO` | 결합된 파형과 샘플 속도를 포함하는 병합된 오디오 출력입니다. | AUDIO |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioMerge/ko.md)

---
**Source fingerprint (SHA-256):** `2a4a7da42835efd03cc67002e617a70c0514524a0ac0ed61d57e499c1283be95`
