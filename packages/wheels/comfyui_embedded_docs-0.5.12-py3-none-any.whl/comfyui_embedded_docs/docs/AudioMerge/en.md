# Merge Audio

The AudioMerge node combines two audio tracks by overlaying their waveforms. It automatically matches the sample rates of both audio inputs and adjusts their lengths to be equal before merging. The node provides several mathematical methods for combining the audio signals and ensures the output remains within acceptable volume levels.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `audio1` | First audio input to merge | AUDIO | Yes | - |
| `audio2` | Second audio input to merge | AUDIO | Yes | - |
| `merge_method` | The method used to combine the audio waveforms. | COMBO | Yes | `"add"`<br>`"mean"`<br>`"subtract"`<br>`"multiply"` |

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `AUDIO` | The merged audio output containing the combined waveform and sample rate | AUDIO |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AudioMerge/en.md)

---
**Source fingerprint (SHA-256):** `3bb8c223e9a5155b5e60f901e8653c6654336a10a56d25ba7a3c5e8f5382ad27`
