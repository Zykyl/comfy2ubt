# Bria 生成式填充

此节点使用 Bria 在图像的蒙版区域内生成物体或场景。它会上传图像和蒙版，将提示词发送到 Bria 生成式填充服务，等待操作完成，并返回编辑后的图像。这是一项付费 API 操作（每次请求 0.0429 美元）。

## 输入

### 通用输入

| 参数 | 描述 | 数据类型 | 必填 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `image` | 要编辑的输入图像。 | IMAGE | 是 | - |
| `mask` | 白色区域将填充生成内容，黑色区域保持不变。蒙版在发送前会进行二值化，因此部分涂抹的区域会被视为白色。必须与图像具有相同的宽高比。 | MASK | 是 | - |
| `prompt` | 描述要在蒙版区域内生成的内容。必须至少包含 1 个字符。（默认值：""） | STRING | 是 | - |
| `negative_prompt` | 描述生成结果中要避免出现的内容的提示词。如果留空，则不会发送到 API。（默认值：""） | STRING | 是 | - |
| `refine_prompt` | 自动调整提示词以获得更好的结果；禁用它可完全按所写内容使用提示词。（默认值：true） | BOOLEAN | 是 | true<br>false |
| `seed` | 生成过程的随机种子。（默认值：42） | INT | 是 | 1 到 2147483647 |
| `内容审核` | 审核设置。设置为 "true" 时，将应用下方的审核选项。（默认值："false"） | DYNAMIC_COMBO | 是 | "false"<br>"true" |

### 审核输入（当 `moderation` = "true" 时）

| 参数 | 描述 | 数据类型 | 必填 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `prompt_content_moderation` | 对提示词应用内容审核。（默认值：false） | BOOLEAN | 否 | true<br>false |
| `visual_input_moderation` | 对输入图像应用内容审核。（默认值：false） | BOOLEAN | 否 | true<br>false |
| `visual_output_moderation` | 对输出图像应用内容审核。（默认值：false） | BOOLEAN | 否 | true<br>false |

**注意：** `prompt` 不能为空。`mask` 必须与 `image` 具有相同的宽高比。蒙版会以 50% 不透明度为阈值进行二值化，因此以低于一半不透明度涂抹的区域会被忽略；如果二值化后蒙版不包含白色区域，节点会报错。

## 输出

| 输出名称 | 描述 | 数据类型 |
|-------------|-------------|-----------|
| `image` | 蒙版区域已由生成内容填充的结果图像。 | IMAGE |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaGenFill/zh.md)

---
**Source fingerprint (SHA-256):** `b23e29d4457f859181d68eaeb4b0238de28f4b18932d68438fa2954739cdc66a`
