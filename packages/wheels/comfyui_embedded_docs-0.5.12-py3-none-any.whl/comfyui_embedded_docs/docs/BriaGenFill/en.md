# Bria Generative Fill

This node generates objects or scenery inside a masked region of an image using Bria. It uploads the image and mask, sends the prompt to the Bria generative fill service, waits for the operation to complete, and returns the edited image. This is a paid API operation (US$0.0429 per request).

## Inputs

### Common Inputs

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `image` | The input image to edit. | IMAGE | Yes | - |
| `mask` | White areas are filled with generated content, black areas are preserved. The mask is binarized before sending with a 50% cutoff: only areas painted above 50% opacity count as white. Must have the same aspect ratio as the image. | MASK | Yes | - |
| `prompt` | Description of what to generate inside the masked region. Must contain at least 1 character. (default: "") | STRING | Yes | - |
| `negative_prompt` | A prompt describing content to avoid in the generated result. If left empty, it is not sent to the API. (default: "") | STRING | Yes | - |
| `refine_prompt` | Automatically adjust the prompt for better results; disable to use the prompt exactly as written. (default: true) | BOOLEAN | Yes | true<br>false |
| `seed` | Seed for the generation process. (default: 42) | INT | Yes | 1 to 2147483647 |
| `moderation` | Moderation settings. When set to "true", the moderation options below are applied. (default: "false") | DYNAMIC_COMBO | Yes | "false"<br>"true" |

### Moderation Inputs (when `moderation` = "true")

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `prompt_content_moderation` | Applies content moderation to the prompt. (default: false) | BOOLEAN | No | true<br>false |
| `visual_input_moderation` | Applies content moderation to the input image. (default: false) | BOOLEAN | No | true<br>false |
| `visual_output_moderation` | Applies content moderation to the output image. (default: false) | BOOLEAN | No | true<br>false |

**Note:** The `prompt` must not be empty. The `mask` must have the same aspect ratio as the `image`. The mask is binarized at 50% opacity, so areas painted at less than half opacity are ignored; if the mask contains no white areas after binarization, the node raises an error.

## Outputs

| Output Name | Description | Data Type |
|-------------|-------------|-----------|
| `image` | The resulting image with the masked region filled by the generated content. | IMAGE |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaGenFill/en.md)

---
**Source fingerprint (SHA-256):** `b23e29d4457f859181d68eaeb4b0238de28f4b18932d68438fa2954739cdc66a`
