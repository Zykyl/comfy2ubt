# ARVideoI2V

This node prepares an image-to-video generation setup for AR (Auto-Regressive) video models that use Causal Forcing or Self-Forcing. It encodes a starting image into latent space with a VAE and stores it in the model's transformer options, so the video sampling process can seed the KV cache before denoising. It uses the same text-to-video model checkpoint, so no separate image-to-video architecture is needed.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `model` | The AR video model to be used for generation. | MODEL | Yes | - |
| `vae` | The VAE model used to encode the starting image into latent space. | VAE | Yes | - |
| `start_image` | The initial image that will serve as the first frame of the generated video. Only the first image in the input batch is used, and only its RGB channels are encoded. | IMAGE | Yes | - |
| `width` | The width of the generated video frames (default: 832). | INT | Yes | 16 to 8192 (step: 16) |
| `height` | The height of the generated video frames (default: 480). | INT | Yes | 16 to 8192 (step: 16) |
| `length` | The total number of frames of the generated video (default: 81). | INT | Yes | 1 to 1024 (step: 4) |
| `batch_size` | The number of video sequences to generate in a single batch (default: 1). | INT | Yes | 1 to 64 |

Note: The start image is resized to the specified `width` and `height` before being encoded. The latent temporal dimension is calculated as `((length - 1) // 4) + 1`, and the latent spatial dimensions are `height / 8` and `width / 8`.

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `MODEL` | The cloned model with the encoded start image stored in its transformer options (`ar_config.initial_latent`), which the sampler uses to seed the KV cache before denoising. | MODEL |
| `LATENT` | A zero-filled latent tensor with shape `[batch_size, 16, lat_t, height // 8, width // 8]`, where `lat_t = ((length - 1) // 4) + 1`. | LATENT |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/ARVideoI2V/en.md)

---
**Source fingerprint (SHA-256):** `984834951b9d5a22aef51c85a5019fd8ba58cdb2d6fff235371ed29f316896d8`
