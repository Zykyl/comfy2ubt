# ARVideoI2V

此节点为使用 Causal Forcing 或 Self-Forcing 的 AR（自回归）视频模型准备图像到视频生成设置。它使用 VAE 将起始图像编码到潜空间，并将其存储在模型的 transformer 选项中，以便视频采样过程可以在去噪前初始化 KV 缓存。它使用相同的文本到视频模型检查点，因此无需单独的图像到视频架构。

## 输入

| 参数 | 描述 | 数据类型 | 必填 | 范围 |
| --- | --- | --- | --- | --- |
| `模型` | 用于生成的 AR 视频模型。 | MODEL | 是 | - |
| `vae` | 用于将起始图像编码到潜空间的 VAE 模型。 | VAE | 是 | - |
| `起始图像` | 将作为生成视频第一帧的初始图像。仅使用输入批次中的第一张图像，并且仅编码其 RGB 通道。 | IMAGE | 是 | - |
| `宽度` | 生成视频帧的宽度（默认值：832）。 | INT | 是 | 16 到 8192 （步长：16） |
| `高度` | 生成视频帧的高度（默认值：480）。 | INT | 是 | 16 到 8192 （步长：16） |
| `长度` | 生成视频的总帧数（默认值：81）。 | INT | 是 | 1 到 1024 （步长：4） |
| `批量大小` | 在单个批次中生成的视频序列数量（默认值：1）。 | INT | 是 | 1 到 64 |

注意：起始图像在编码前会调整到指定的 `width` 和 `height`。潜空间的时间维度计算为 `((length - 1) // 4) + 1`，空间维度为 `height / 8` 和 `width / 8`。

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `MODEL` | 克隆后的模型，其中编码后的起始图像存储在其 transformer 选项（`ar_config.initial_latent`）中，采样器在去噪前使用它来初始化 KV 缓存。 | MODEL |
| `LATENT` | 一个全零填充的潜空间张量，形状为 `[batch_size, 16, lat_t, height // 8, width // 8]`，其中 `lat_t = ((length - 1) // 4) + 1`。 | LATENT |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/ARVideoI2V/zh.md)

---
**Source fingerprint (SHA-256):** `984834951b9d5a22aef51c85a5019fd8ba58cdb2d6fff235371ed29f316896d8`
