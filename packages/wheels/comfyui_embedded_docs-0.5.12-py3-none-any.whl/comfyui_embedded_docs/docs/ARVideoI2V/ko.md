# ARVideoI2V

이 노드는 Causal Forcing 또는 Self-Forcing을 사용하는 AR(Auto-Regressive) 비디오 모델을 위한 이미지-투-비디오 생성 설정을 준비합니다. VAE를 사용해 시작 이미지를 잠재 공간으로 인코딩하고 이를 모델의 transformer 옵션에 저장하여, 비디오 샘플링 과정이 디노이징 전에 KV 캐시를 시드할 수 있게 합니다. 동일한 text-to-video 모델 체크포인트를 사용하므로 별도의 image-to-video 아키텍처가 필요하지 않습니다.

## 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 | 범위 |
| --- | --- | --- | --- | --- |
| `model` | 생성에 사용할 AR 비디오 모델입니다. | MODEL | 예 | - |
| `vae` | 시작 이미지를 잠재 공간으로 인코딩하는 데 사용되는 VAE 모델입니다. | VAE | 예 | - |
| `start_image` | 생성된 비디오의 첫 프레임으로 사용될 초기 이미지입니다. 입력 배치의 첫 번째 이미지만 사용되며, RGB 채널만 인코딩됩니다. | IMAGE | 예 | - |
| `width` | 생성된 비디오 프레임의 너비입니다(기본값: 832). | INT | 예 | 16  ~  8192 (단계: 16) |
| `height` | 생성된 비디오 프레임의 높이입니다(기본값: 480). | INT | 예 | 16  ~  8192 (단계: 16) |
| `length` | 생성된 비디오의 총 프레임 수입니다(기본값: 81). | INT | 예 | 1  ~  1024 (단계: 4) |
| `batch_size` | 단일 배치에서 생성할 비디오 시퀀스 수입니다(기본값: 1). | INT | 예 | 1  ~  64 |

참고: 시작 이미지는 인코딩되기 전에 지정된 `width` 및 `height`로 크기 조정됩니다. 잠재 시간 차원은 `((length - 1) // 4) + 1`로 계산되며, 잠재 공간 차원은 `height / 8` 및 `width / 8`입니다.

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
| --- | --- | --- |
| `MODEL` | 인코딩된 시작 이미지가 transformer 옵션(`ar_config.initial_latent`)에 저장된 복제 모델로, 샘플러가 디노이징 전에 KV 캐시를 시드하는 데 사용합니다. | MODEL |
| `LATENT` | 형태가 `[batch_size, 16, lat_t, height // 8, width // 8]`인 0으로 채워진 잠재 텐서이며, 여기서 `lat_t = ((length - 1) // 4) + 1`입니다. | LATENT |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/ARVideoI2V/ko.md)

---
**Source fingerprint (SHA-256):** `984834951b9d5a22aef51c85a5019fd8ba58cdb2d6fff235371ed29f316896d8`
