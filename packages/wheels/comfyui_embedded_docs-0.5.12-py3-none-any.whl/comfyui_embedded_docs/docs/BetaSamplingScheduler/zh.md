# Beta采样调度器

BetaSamplingScheduler 节点使用 beta 调度算法为采样过程生成一系列噪声水平（sigmas）。它接收一个模型和配置参数，以创建自定义的噪声调度，从而控制图像生成过程中的去噪过程。该调度器允许通过 alpha 和 beta 参数对噪声降低轨迹进行微调。

## 输入
| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `模型` | 用于采样的模型，提供模型采样对象 | MODEL | 是 | - |
| `步数` | 要为其生成 sigmas 的采样步数（默认值：20） | INT | 是 | 1 到 10000 |
| `alpha` | beta 调度器的 alpha 参数，控制调度曲线（默认值：0.6，高级参数） | FLOAT | 是 | 0.0 到 50.0 |
| `beta` | beta 调度器的 beta 参数，控制调度曲线（默认值：0.6，高级参数） | FLOAT | 是 | 0.0 到 50.0 |

## 输出
| Output Name | Description | Data Type |
| --- | --- | --- |
| `SIGMAS` | 用于采样过程的噪声水平（sigmas）序列 | SIGMAS |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BetaSamplingScheduler/zh.md)

---
**Source fingerprint (SHA-256):** `80adae3cbedff7fe544a1fbcf638af7965f1216e422931063ecf67da53ddff95`
