# BetaSamplingScheduler

The BetaSamplingScheduler node generates a sequence of noise levels (sigmas) for the sampling process using a beta scheduling algorithm. It takes a model and configuration parameters to create a customized noise schedule that controls the denoising process during image generation. This scheduler allows fine-tuning of the noise reduction trajectory through alpha and beta parameters.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `model` | The model used for sampling, which provides the model sampling object | MODEL | Yes | - |
| `steps` | The number of sampling steps to generate sigmas for (default: 20) | INT | Yes | 1 to 10000 |
| `alpha` | Alpha parameter for the beta scheduler, controlling the scheduling curve (default: 0.6, advanced parameter) | FLOAT | Yes | 0.0 to 50.0 (step 0.01) |
| `beta` | Beta parameter for the beta scheduler, controlling the scheduling curve (default: 0.6, advanced parameter) | FLOAT | Yes | 0.0 to 50.0 (step 0.01) |

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `SIGMAS` | A sequence of noise levels (sigmas) used for the sampling process | SIGMAS |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BetaSamplingScheduler/en.md)

---
**Source fingerprint (SHA-256):** `80adae3cbedff7fe544a1fbcf638af7965f1216e422931063ecf67da53ddff95`
