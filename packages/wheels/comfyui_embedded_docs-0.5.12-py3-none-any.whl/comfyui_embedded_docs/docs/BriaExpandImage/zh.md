# Bria 扩展图像

Bria Expand Image 通过使用 Bria 生成新内容，将图像扩展到其原始边界之外。它允许您选择目标宽高比、自定义比例，或通过手动放置原始图像来定义画布。扩展可以通过文本提示进行引导，如果提示留空，Bria 将自动生成一个。

## 输入

### 通用输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `image` | 要扩展的输入图像。 | IMAGE | 是 | — |
| `expand_mode` | 扩展后图像的目标形状：预设宽高比、自定义比例，或手动将原始图像放置在画布上。手动是唯一可以达到高于 1:2 的画布的模式。选择 `custom_ratio` 会显示 `ratio_width` 和 `ratio_height`。选择 `manual` 会显示画布和图像放置参数。 | DYNAMIC_COMBO | 是 | `"1:1"`<br>`"2:3"`<br>`"3:2"`<br>`"3:4"`<br>`"4:3"`<br>`"4:5"`<br>`"5:4"`<br>`"9:16"`<br>`"16:9"`<br>`"custom_ratio"`<br>`"manual"` |
| `prompt` | 扩展场景的可选描述；当为空时，Bria 会根据图像生成一个。默认值：空字符串。 | STRING | 是 | 任意字符串 |
| `negative_prompt` | 用于扩展的可选负面提示。默认值：空字符串。 | STRING | 是 | 任意字符串 |
| `seed` | 随机生成过程的种子。默认值：42。 | INT | 是 | 1–2147483647 |
| `moderation` | 审核设置。当设置为 `true` 时，会显示额外的审核选项。 | DYNAMIC_COMBO | 是 | `"false"`<br>`"true"` |

### 自定义比例输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `ratio_width` | 目标比例的宽度边：21 和 9 得到 21:9。默认值：21。 | INT | 是 | 1–100 |
| `ratio_height` | 目标比例的高度边：21 和 9 得到 21:9。Bria 只接受宽度/高度在 0.5 到 3.0 之间，因此任何高于 1:2 的比例都需要手动模式。默认值：9。 | INT | 是 | 1–100 |

### 手动输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `canvas_width` | 输出画布的宽度（像素）。默认值：1000。 | INT | 是 | 64–5000 |
| `canvas_height` | 输出画布的高度（像素）。默认值：1000。 | INT | 是 | 64–5000 |
| `image_width` | 画布内原始图像的宽度。默认值：500。 | INT | 是 | 1–5000 |
| `image_height` | 画布内原始图像的高度。默认值：500。 | INT | 是 | 1–5000 |
| `image_x` | 图像左上角在画布内的 X 位置；可能落在画布外，从而裁剪图像。默认值：250。 | INT | 是 | -5000–5000 |
| `image_y` | 图像左上角在画布内的 Y 位置；可能落在画布外，从而裁剪图像。默认值：250。 | INT | 是 | -5000–5000 |

### 审核输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `prompt_content_moderation` | 如果启用，则审核提示内容。默认值：false。仅在 `moderation` 为 `true` 时可用。 | BOOLEAN | 是 | true/false |
| `visual_input_moderation` | 如果启用，则审核视觉输入。默认值：false。仅在 `moderation` 为 `true` 时可用。 | BOOLEAN | 是 | true/false |
| `visual_output_moderation` | 如果启用，则审核视觉输出。默认值：false。仅在 `moderation` 为 `true` 时可用。 | BOOLEAN | 是 | true/false |

预设宽高比选项（`1:1`、`2:3`、`3:2`、`3:4`、`4:3`、`4:5`、`5:4`、`9:16`、`16:9`）没有额外的输入。

当 `expand_mode` 为 `custom_ratio` 时，`ratio_width` 和 `ratio_height` 定义目标宽高比。Bria 只接受宽度与高度的比例在 0.5 到 3.0 之间。如果比例超出此范围，将引发错误，应改用 `manual` 模式。

当 `expand_mode` 为 `manual` 时，原始图像会以指定的大小和位置放置在画布上。图像可能延伸到画布之外，在这种情况下，外部部分会被裁剪。

当 `moderation` 为 `true` 时，三个审核布尔值会发送给 Bria。当 `moderation` 为 `false` 时，它们会被忽略。

## 输出

| 输出名称 | 描述 | 数据类型 |
|-------------|-------------|-----------|
| `image` | 由 Bria 生成的扩展图像。 | IMAGE |
| `prompt` | 用于扩展的提示；当提示输入为空时由 Bria 自动生成。 | STRING |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaExpandImage/zh.md)

---
**Source fingerprint (SHA-256):** `d2c9431837f200ccbcb39037f7b26013494c4dea3d40d899db4e717ddbbea71c`
