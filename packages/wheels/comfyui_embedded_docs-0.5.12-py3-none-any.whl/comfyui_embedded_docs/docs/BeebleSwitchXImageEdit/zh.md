# Beeble SwitchX 图像编辑

## ## 概述

使用 Beeble SwitchX 编辑单张图像。此节点可以切换场景中的任何元素（背景、光照、服装），同时保留原始主体的像素。提供参考图像和/或文本提示来描述新的外观。最大分辨率约为 277 万像素。

## ## 输入

| 参数 | 描述 | 数据类型 | 是否必填 | 取值范围 |
| --- | --- | --- | --- | --- |
| `图像` | 要编辑的源图像。 | IMAGE | 是 | - |
| `提示词` | 所需新外观的文本描述（例如："身穿闪亮盔甲的骑士"）。 | STRING | 是 | - |
| `alpha_mode` | 处理 Alpha 遮罩的方式。"select" 使用关键帧选择主体，"fill" 替换整个图像而不使用独立遮罩，"custom" 使用用户提供的遮罩。 | COMBO | 是 | `"select"`<br>`"fill"`<br>`"custom"` |
| `最大分辨率` | 输出图像的最大分辨率。更高分辨率会消耗更多积分。 | COMBO | 是 | `"1080p"`<br>`"720p"` |
| `种子` | 用于结果可复现的种子值。 | INT | 是 | - |
| `参考图像` | 可选的参考图像，用于引导新场景元素的风格或外观。 | IMAGE | 否 | - |

**关于 `alpha_mode` 的说明：** 当 `alpha_mode` 设置为 `"select"` 时，您还必须提供 `alpha_keyframe`（用于选择主体的关键帧图像）。当设置为 `"custom"` 时，您必须提供 `alpha_mask`（用户创建的遮罩）。当设置为 `"fill"` 时，无需提供 Alpha 输入。

## ## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `图像` | 已切换场景元素的编辑后图像。 | IMAGE |
| `alpha` | Beeble 使用的 Alpha 遮罩。对于 "fill" 模式，此输出为空，因为该模式没有独立遮罩。 | MASK |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BeebleSwitchXImageEdit/zh.md)

---
**Source fingerprint (SHA-256):** `41f23435686626e3ade28708fcb1da192ded347b210080ee9b17834ea8b727fb`
