# Beeble SwitchX Image Edit

Edit a single image with Beeble SwitchX. This node can switch anything in the scene (background, lighting, costume) while preserving the original subject's pixels. Provide a reference image and/or text prompt to describe the new look. Maximum resolution is approximately 2.77 megapixels.

## Inputs

| Parameter | Description | Data Type | Required | Range |
|-----------|-------------|-----------|----------|-------|
| `image` | The source image to edit. | IMAGE | Yes | - |
| `prompt` | A text description of the desired new look (e.g., "a knight in shining armor"). | STRING | Yes | - |
| `alpha_mode` | How to handle the alpha matte. "select" uses a keyframe to select the subject, "fill" replaces the entire image without a separate matte, "custom" uses a user-provided mask. | COMBO | Yes | `"select"`<br>`"fill"`<br>`"custom"` |
| `max_resolution` | The maximum resolution for the output image. Higher resolution costs more credits. | COMBO | Yes | `"1080p"`<br>`"720p"` |
| `seed` | A seed value for reproducibility. | INT | Yes | - |
| `reference_image` | An optional reference image to guide the style or appearance of the new scene elements. | IMAGE | No | - |

**Note on `alpha_mode`:** When `alpha_mode` is set to `"select"`, you must also provide an `alpha_keyframe` (a keyframe image used to select the subject). When set to `"custom"`, you must provide an `alpha_mask` (a user-created mask). When set to `"fill"`, no alpha input is needed.

## Outputs

| Output Name | Description | Data Type |
|-------------|-------------|-----------|
| `image` | The edited image with the scene elements switched. | IMAGE |
| `alpha` | The alpha matte used by Beeble. Empty for "fill" mode, which has no separate matte. | MASK |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BeebleSwitchXImageEdit/en.md)

---
**Source fingerprint (SHA-256):** `6fd10dff6ac4f1a15fd05de7a6ff6eda988e60dd4ef32bc8c792480fbbf0c92b`
