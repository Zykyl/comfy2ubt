# Beeble SwitchX 이미지 편집

## 개요

Beeble SwitchX를 사용하여 단일 이미지를 편집합니다. 이 노드는 원본 피사체의 픽셀을 보존하면서 장면의 모든 요소(배경, 조명, 의상)를 전환할 수 있습니다. 새로운 모습을 설명하기 위해 참조 이미지 및/또는 텍스트 프롬프트를 제공하세요. 최대 해상도는 약 277만 화소입니다.

## 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 | 범위 |
| --- | --- | --- | --- | --- |
| `image` | 편집할 원본 이미지입니다. | IMAGE | 예 | - |
| `prompt` | 원하는 새로운 모습에 대한 텍스트 설명입니다 (예: "반짝이는 갑옷을 입은 기사"). | STRING | 예 | - |
| `alpha_mode` | 알파 매트를 처리하는 방식입니다. "select"는 키프레임을 사용하여 피사체를 선택하고, "fill"은 별도의 매트 없이 전체 이미지를 대체하며, "custom"은 사용자가 제공한 마스크를 사용합니다. | COMBO | 예 | `"select"`<br>`"fill"`<br>`"custom"` |
| `max_resolution` | 출력 이미지의 최대 해상도입니다. 해상도가 높을수록 더 많은 크레딧이 소모됩니다. | COMBO | 예 | `"1080p"`<br>`"720p"` |
| `seed` | 재현성을 위한 시드 값입니다. | INT | 예 | - |
| `reference_image` | 새 장면 요소의 스타일이나 외관을 안내하는 선택적 참조 이미지입니다. | IMAGE | 아니요 | - |

**`alpha_mode` 참고 사항:** `alpha_mode`가 `"select"`로 설정된 경우 `alpha_keyframe`(피사체 선택에 사용되는 키프레임 이미지)도 함께 제공해야 합니다. `"custom"`으로 설정된 경우 `alpha_mask`(사용자가 생성한 마스크)를 제공해야 합니다. `"fill"`로 설정된 경우 알파 입력이 필요하지 않습니다.

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
| --- | --- | --- |
| `image` | 장면 요소가 전환된 편집된 이미지입니다. | IMAGE |
| `alpha` | Beeble에서 사용하는 알파 매트입니다. "fill" 모드에서는 별도의 매트가 없으므로 비어 있습니다. | MASK |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BeebleSwitchXImageEdit/ko.md)

---
**Source fingerprint (SHA-256):** `41f23435686626e3ade28708fcb1da192ded347b210080ee9b17834ea8b727fb`
