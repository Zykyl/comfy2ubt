# 调整亮度

Adjust Brightness 节点用于调整图像的亮度。它通过将图像的颜色值与 `factor` 相乘，并将结果限制在有效的 0.0 到 1.0 范围内来实现。当 `factor` 为 1.0 时，图像保持不变；小于 1.0 时图像变暗；大于 1.0 时图像变亮。

## 输入

| 参数 | 描述 | 数据类型 | 是否必填 | 范围 |
| --- | --- | --- | --- | --- |
| `image` | 要调整的输入图像。支持单个图像或一批图像。 | IMAGE | 是 | - |
| `系数` | 亮度因子。1.0 = 不变，<1.0 = 变暗，>1.0 = 变亮。（默认值：1.0） | FLOAT | 否 | 0.0 - 2.0 |

注意：如果输入图像带有 Alpha 通道（RGBA），则仅调整颜色通道。Alpha 通道将原样从输入中复制，因为它存储的是透明度而非颜色。

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `图像` | 调整亮度后的输出图像。如果输入带有 Alpha 通道，则 Alpha 值保持不变。 | IMAGE |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AdjustBrightness/zh.md)

---
**Source fingerprint (SHA-256):** `64c1499d16deb5922fa63538182cd227e8f2ba9ded5962064ce9f228a0f4a163`
