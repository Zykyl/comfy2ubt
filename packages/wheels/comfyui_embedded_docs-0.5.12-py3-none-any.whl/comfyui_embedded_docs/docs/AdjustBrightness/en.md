# Adjust Brightness

The Adjust Brightness node changes how bright an image looks. It multiplies the image's color values by a `factor` and keeps the results within the valid 0.0 to 1.0 range. A factor of 1.0 leaves the image unchanged, values below 1.0 make it darker, and values above 1.0 make it brighter.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `image` | The input image to adjust. Accepts a single image or a batch of images. | IMAGE | Yes | - |
| `factor` | Brightness factor. 1.0 = no change, <1.0 = darker, >1.0 = brighter. (default: 1.0) | FLOAT | No | 0.0 - 2.0 |

Note: If the input image has an alpha channel (RGBA), only the color channels are adjusted. The alpha channel is copied from the input unchanged because it stores transparency, not color.

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `image` | The output image with adjusted brightness. If the input has an alpha channel, the alpha values remain unchanged. | IMAGE |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AdjustBrightness/en.md)

---
**Source fingerprint (SHA-256):** `64c1499d16deb5922fa63538182cd227e8f2ba9ded5962064ce9f228a0f4a163`
