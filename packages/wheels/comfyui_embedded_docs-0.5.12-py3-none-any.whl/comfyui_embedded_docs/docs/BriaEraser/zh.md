# Bria 擦除

Bria Eraser 使用 Bria API 从图像中移除对象或区域。您提供一张图像和一个标出要移除区域的遮罩；该节点会将两者上传到 Bria，运行擦除任务，等待其完成，并返回已编辑的图像，其中被遮罩的区域已被擦除。

## 输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `image` | 包含要移除的对象或区域的输入图像。 | IMAGE | 是 | - |
| `mask` | 白色区域会被擦除，黑色区域会被保留。遮罩在发送前会进行二值化，因此部分绘制的区域会被视为白色。必须与图像具有相同的宽高比。 | MASK | 是 | - |
| `mask_type` | 遮罩来源类型。"manual" 用于手绘或画笔遮罩；"automatic" 用于由分割模型（如 SAM）生成的遮罩。 | COMBO | 是 | "manual"<br>"automatic" |
| `moderation` | 审核设置。设置为 "true" 可对输入和/或输出图像启用视觉内容审核。 | DYNAMIC_COMBO | 是 | "false"<br>"true" |

当 `moderation` 设置为 "true" 时，两个额外的布尔设置将可用：

- `visual_input_moderation` — 对输入图像应用视觉内容审核（默认：false）
- `visual_output_moderation` — 对输出图像应用视觉内容审核（默认：false）

注意：遮罩必须与图像的宽高比匹配，否则请求会失败。遮罩在发送到 API 之前会转换为二值（黑白）遮罩：以低于一半不透明度绘制的区域会被忽略，部分绘制的区域会被视为白色并会被擦除。遮罩必须至少包含一些白色区域；空遮罩会导致请求失败，因为没有可擦除的内容。

## 输出

| 输出名称 | 描述 | 数据类型 |
|-------------|-------------|-----------|
| `image` | 已编辑的图像，其中被遮罩的对象或区域已被移除。 | IMAGE |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BriaEraser/zh.md)

---
**Source fingerprint (SHA-256):** `5528b7a3cb4d0a7b1b28acbc642a8bd21e2eacf5aa225403d6344c29f0cdba80`
