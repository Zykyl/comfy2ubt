# AlignYourSteps调度器

AlignYourStepsScheduler 节点会根据不同的模型类型为去噪过程生成 sigma 值（噪声水平）。它会为采样过程的每一步计算合适的噪声水平，并根据 `denoise` 参数调整总步数，从而帮助采样步数与不同扩散模型的具体需求相匹配。

## 输入

| 参数 | 描述 | 数据类型 | 是否必填 | 取值范围 |
| --- | --- | --- | --- | --- |
| `模型类型` | 指定用于 sigma 计算的模型类型（默认值："SD1"） | COMBO | 是 | `"SD1"`<br>`"SDXL"`<br>`"SVD"` |
| `步数` | 要生成的采样总步数（默认值：10） | INT | 是 | 1 到 10000 |
| `降噪` | 控制图像的去噪程度，1.0 表示使用全部步数，值越小使用的步数越少（默认值：1.0） | FLOAT | 是 | 0.0 到 1.0（步长：0.01） |

注意：每种模型类型都内置了一个噪声水平调度表，包含 11 个 sigma 值（对应 10 步）。当 `denoise` 为 0.0 时，该节点返回空的 sigma 张量。当 `denoise` 介于 0.0 和 1.0 之间时，有效步数按 `round(steps × denoise)` 计算，并且只使用 sigma 调度表中对应的最后一部分。如果请求的 `steps` 值与内置调度表的长度不匹配，噪声水平会通过对数线性插值来匹配请求的步数。最终的 sigma 值始终设置为 0。

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `sigmas` | 返回为去噪过程计算得到的 sigma 值 | SIGMAS |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AlignYourStepsScheduler/zh.md)

---
**Source fingerprint (SHA-256):** `3adbe1016c1ff4b9b7ad3737f50b168f54444d4ca355488e60537d1136f85d3f`
