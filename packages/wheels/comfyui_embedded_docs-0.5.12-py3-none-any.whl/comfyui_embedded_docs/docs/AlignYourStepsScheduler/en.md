# AlignYourStepsScheduler

The AlignYourStepsScheduler node generates sigma values (noise levels) for the denoising process based on different model types. It calculates appropriate noise levels for each step of the sampling process and adjusts the total number of steps according to the `denoise` parameter, helping align the sampling steps with the specific requirements of different diffusion models.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `model_type` | Specifies the type of model to use for sigma calculation (default: "SD1") | COMBO | Yes | `"SD1"`<br>`"SDXL"`<br>`"SVD"` |
| `steps` | The total number of sampling steps to generate (default: 10) | INT | Yes | 1 to 10000 |
| `denoise` | Controls how much to denoise the image, where 1.0 uses all steps and lower values use fewer steps (default: 1.0) | FLOAT | Yes | 0.0 to 1.0 (step: 0.01) |

Note: Each model type has a built-in noise level schedule containing 11 sigma values (for 10 steps). When `denoise` is 0.0, the node returns an empty sigma tensor. When `denoise` is between 0.0 and 1.0, the effective number of steps is calculated as `round(steps × denoise)`, and only the corresponding last portion of the sigma schedule is used. If the requested `steps` value does not match the built-in schedule length, the noise levels are log-linearly interpolated to match the requested step count. The final sigma value is always set to 0.

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `sigmas` | Returns the calculated sigma values for the denoising process | SIGMAS |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AlignYourStepsScheduler/en.md)

---
**Source fingerprint (SHA-256):** `3adbe1016c1ff4b9b7ad3737f50b168f54444d4ca355488e60537d1136f85d3f`
