# Batch Images

The Batch Images node combines multiple individual images into a single batch. It takes a variable number of image inputs and outputs them as one batched image tensor, allowing them to be processed together in subsequent nodes.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `images` | A dynamic list of image inputs. You can add between 2 and 50 images to be combined into a batch. The node interface allows you to add more image input slots as needed. | IMAGE | Yes | 2 to 50 inputs |

**Note:** You must connect at least two images for the node to function. The first input slot is always required, and you can add more using the "+" button that appears in the node interface.

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `output` | A single batched image tensor containing all the input images stacked together. | IMAGE |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BatchImagesNode/en.md)

---
**Source fingerprint (SHA-256):** `f756fb15760cd2518da9c3f88281d3ab3361b4c2b4820fe2be152e4db1cf102c`
