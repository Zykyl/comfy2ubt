# AddNoise

This node adds controlled noise to a latent image using a specified noise generator and sigma values. It processes the input through the model's sampling system to apply noise scaling appropriate for the given sigma range, returning a new latent representation with the noise applied. This node is currently marked as experimental.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `model` | The model containing sampling parameters and processing functions | MODEL | Yes | - |
| `noise` | The noise generator that produces the base noise pattern | NOISE | Yes | - |
| `sigmas` | Sigma values controlling the noise scaling intensity. If empty, the node returns the original latent image unchanged. When multiple sigmas are provided, the noise scale is calculated as the absolute difference between the first and last sigma values. When only one sigma is provided, that value is used directly as the scale. | SIGMAS | Yes | - |
| `latent_image` | The input latent representation to which noise will be added. Empty latent images (containing only zeros) are not shifted during processing. | LATENT | Yes | - |

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `LATENT` | The modified latent representation with added noise. Any NaN or infinite values in the output are converted to zeros for stability. | LATENT |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AddNoise/en.md)

---
**Source fingerprint (SHA-256):** `6b11db10af9a2b8ea24dbf3b40c08d7e37de39df746e3966e5bfc94b84dee068`
