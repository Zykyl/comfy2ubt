# AutogrowNamesTestNode

このノードは Autogrow 入力機能のテストです。事前定義された名前を持つ float 入力の動的グループを受け取り、その値をカンマ区切りの単一の文字列に結合します。

## 入力

| パラメータ | 説明 | データ型 | 必須 | 範囲 |
| --- | --- | --- | --- | --- |
| `autogrow` | 動的入力グループです。複数の float 入力を追加でき、それぞれに「a」「b」「c」のいずれかの事前定義された名前を付けられます。ノードはこれらの名前付き入力の任意の組み合わせを受け付けます。 | FLOAT | はい | 名前付きスロット: `a`, `b`, `c` |

**注記:** `autogrow` 入力は動的です。「a」「b」「c」という名前の個々の float 入力は、必要に応じて追加または削除できます。提供されたすべての値はノードによって処理されます。

## 出力

| 出力名 | 説明 | データ型 |
| --- | --- | --- |
| `output` | 提供されたすべての float 入力の値をカンマで結合した単一の文字列です。 | STRING |

> このドキュメントは AI によって生成されました。エラーを見つけた場合や改善のご提案がある場合は、ぜひ貢献してください！ [GitHub で編集](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AutogrowNamesTestNode/ja.md)

---
**Source fingerprint (SHA-256):** `dac384c9486ac645d0d292fc891603cbfa6d362baa0a1e939c43257bbc0b06a0`
