# AutogrowNamesTestNode

此节点用于测试 Autogrow 输入功能。它接受一组动态的 FLOAT 输入，每个输入都有预定义名称，并将它们的值合并为单个逗号分隔的字符串。

## 输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
| --- | --- | --- | --- | --- |
| `autogrow` | 动态输入组。你可以添加多个 FLOAT 输入，每个输入使用列表中的预定义名称："a"、"b" 或 "c"。该节点接受这些命名输入的任意组合。 | FLOAT | 是 | 命名槽位：`a`、`b`、`c` |

**注意：** `autogrow` 输入是动态的。可以根据需要添加或移除名为 "a"、"b" 和 "c" 的单个 FLOAT 输入。节点会处理所有提供的值。

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `output` | 一个字符串，包含所有提供的 FLOAT 输入的值，并用逗号连接在一起。 | STRING |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AutogrowNamesTestNode/zh.md)

---
**Source fingerprint (SHA-256):** `dac384c9486ac645d0d292fc891603cbfa6d362baa0a1e939c43257bbc0b06a0`
