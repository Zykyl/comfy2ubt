# AutogrowNamesTestNode

이 노드는 Autogrow 입력 기능에 대한 테스트입니다. 미리 정의된 이름을 가진 FLOAT 입력의 동적 그룹을 받아들이고, 해당 값들을 쉼표로 구분된 하나의 문자열로 결합합니다.

## 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 | 범위 |
| --- | --- | --- | --- | --- |
| `autogrow` | 동적 입력 그룹입니다. 여러 FLOAT 입력을 추가할 수 있으며, 각 입력은 목록에서 미리 정의된 이름인 "a", "b", "c" 중 하나를 가집니다. 노드는 이러한 명명된 입력의 모든 조합을 허용합니다. | FLOAT | 예 | 명명된 슬롯: `a`, `b`, `c` |

**참고:** `autogrow` 입력은 동적입니다. "a", "b", "c"라는 이름의 개별 FLOAT 입력은 필요에 따라 추가하거나 제거할 수 있습니다. 제공된 모든 값은 노드에서 처리됩니다.

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
| --- | --- | --- |
| `output` | 제공된 모든 FLOAT 입력의 값을 쉼표로 결합한 하나의 문자열입니다. | STRING |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AutogrowNamesTestNode/ko.md)

---
**Source fingerprint (SHA-256):** `dac384c9486ac645d0d292fc891603cbfa6d362baa0a1e939c43257bbc0b06a0`
