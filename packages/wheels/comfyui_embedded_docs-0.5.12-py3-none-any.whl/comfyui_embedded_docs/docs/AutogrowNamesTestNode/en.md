# AutogrowNamesTestNode

This node is a test for the Autogrow input feature. It accepts a dynamic group of float inputs, each with a predefined name, and combines their values into a single comma-separated string.

## Inputs

| Parameter | Description | Data Type | Required | Range |
| --- | --- | --- | --- | --- |
| `autogrow` | A dynamic input group. You can add multiple float inputs, each with a predefined name from the list: "a", "b", or "c". The node accepts any combination of these named inputs. | FLOAT | Yes | Named slots: `a`, `b`, `c` |

**Note:** The `autogrow` input is dynamic. Individual float inputs named "a", "b", and "c" can be added or removed as needed. All provided values are processed by the node.

## Outputs

| Output Name | Description | Data Type |
| --- | --- | --- |
| `output` | A single string containing the values from all provided float inputs, joined together with commas. | STRING |

> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AutogrowNamesTestNode/en.md)

---
**Source fingerprint (SHA-256):** `dac384c9486ac645d0d292fc891603cbfa6d362baa0a1e939c43257bbc0b06a0`
