# BerniniConditioning

BerniniConditioning 节点为 Wan2.2-A14B 模型准备视频和图像条件数据。它使用提供的 VAE 对源视频、参考视频和参考图像进行编码，然后将它们作为上下文令牌附加到条件数据中。任务将根据连接的输入自动推断。

## ## 输入

| 参数 | 描述 | 数据类型 | 是否必需 | 范围 |
|-----------|-------------|-----------|----------|-------|
| `positive` | 正向条件数据 | CONDITIONING | 是 | - |
| `negative` | 负向条件数据 | CONDITIONING | 是 | - |
| `vae` | 用于编码视频和图像输入的 VAE 模型 | VAE | 是 | - |
| `宽度` | 输出潜变量的宽度（默认值：832） | INT | 是 | 16 至 8192（步长：16） |
| `高度` | 输出潜变量的高度（默认值：480） | INT | 是 | 16 至 8192（步长：16） |
| `长度` | 输出潜变量的帧数（默认值：81） | INT | 是 | 1 至 8192（步长：4） |
| `批量大小` | 单批次生成的视频数量（默认值：1） | INT | 是 | 1 至 4096 |
| `源视频` | 要编辑或重新造型的源视频（v2v, rv2v）。会调整至 width/height 尺寸并裁剪至 length 长度。 | IMAGE | 否 | - |
| `参考视频` | 要插入到源视频中的视频（ads2v）。按长度裁剪并保持宽高比缩放（长边限制为 ref_max_size）。 | IMAGE | 否 | - |
| `参考图像` | 作为上下文令牌注入的参考图像（r2v, rv2v）。每张图像按其原始宽高比独立编码（长边限制为 ref_max_size）。最多可提供 8 张图像。 | IMAGE | 否 | 0 至 8 张图像 |
| `参考最大尺寸` | reference_video 和 reference_images 长边的最大尺寸。按比例调整大小并对齐至 16px（默认值：848）。 | INT | 否 | 16 至 8192（步长：16） |

**注意：** 任务类型根据连接的输入推断：
- 未连接任何输入 → 文本到视频（t2v）
- 仅连接 `source_video` → 视频到视频（v2v）
- 连接 `source_video` + `reference_images` → 参考引导的视频编辑（rv2v）
- 仅连接 `reference_images` → 参考到视频（r2v）
- 连接 `source_video` + `reference_video` → 将图像/视频插入视频（ads2v）
上下文流按固定顺序附加：`source_video`（源 ID 1），然后是 `reference_video`（源 ID 2），再是每张参考图像（源 ID 3、4...）。包含多张图像的参考图像输入会为每张图像贡献一个流。

## ## 输出

| 输出名称 | 描述 | 数据类型 |
|-------------|-------------|-----------|
| `positive` | 附加了上下文潜变量的正向条件数据 | CONDITIONING |
| `negative` | 附加了上下文潜变量的负向条件数据 | CONDITIONING |
| `latent` | 维度与指定的宽度、高度、长度和批次大小匹配的空潜变量张量 | LATENT |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BerniniConditioning/zh.md)

---
**Source fingerprint (SHA-256):** `3535bbe9a1ae007dc579242b44787ab315479a820eb0da680eab9b870ab60699`
