# BerniniConditioning

BerniniConditioning 노드는 Wan2.2-A14B 모델을 위한 비디오 및 이미지 컨디셔닝 데이터를 준비합니다. 제공된 VAE를 사용하여 소스 비디오, 참조 비디오 및 참조 이미지를 인코딩한 후, 이를 컨텍스트 내 토큰으로 컨디셔닝 데이터에 첨부합니다. 작업은 연결된 입력에서 자동으로 유추됩니다.

## 입력

| 매개변수 | 설명 | 데이터 타입 | 필수 여부 | 범위 |
|-----------|-------------|-----------|----------|-------|
| `positive` | 긍정 컨디셔닝 데이터 | CONDITIONING | 예 | - |
| `negative` | 부정 컨디셔닝 데이터 | CONDITIONING | 예 | - |
| `vae` | 비디오 및 이미지 입력을 인코딩하는 데 사용되는 VAE 모델 | VAE | 예 | - |
| `width` | 출력 잠재 변수의 너비(기본값: 832) | INT | 예 | 16 ~ 8192 (단위: 16) |
| `height` | 출력 잠재 변수의 높이(기본값: 480) | INT | 예 | 16 ~ 8192 (단위: 16) |
| `length` | 출력 잠재 변수의 프레임 수(기본값: 81) | INT | 예 | 1 ~ 8192 (단위: 4) |
| `batch_size` | 단일 배치에서 생성할 비디오 수(기본값: 1) | INT | 예 | 1 ~ 4096 |
| `source_video` | 편집 또는 스타일 변경할 소스 비디오(v2v, rv2v). 너비/높이로 크기 조정되고 길이에 맞게 잘립니다. | IMAGE | 아니요 | - |
| `reference_video` | 소스 비디오에 삽입할 비디오(ads2v). 길이에 맞게 잘리고 종횡비를 유지한 채 크기가 조정됩니다(긴 변은 ref_max_size로 제한). | IMAGE | 아니요 | - |
| `reference_images` | 컨텍스트 내 토큰으로 주입되는 참조 이미지(r2v, rv2v). 각 이미지는 고유한 기본 종횡비로 개별적으로 인코딩됩니다(긴 변은 ref_max_size로 제한). 최대 8개의 이미지를 제공할 수 있습니다. | IMAGE | 아니요 | 0 ~ 8개 이미지 |
| `ref_max_size` | reference_video 및 reference_images의 긴 쪽 최대 크기. 종횡비를 유지하며 크기 조정되고 16px 단위로 맞춰집니다(기본값: 848). | INT | 아니요 | 16 ~ 8192 (단위: 16) |

**참고:** 작업은 어떤 입력이 연결되었는지에 따라 결정됩니다:
- 연결된 입력 없음 → 텍스트-투-비디오 (t2v)
- `source_video`만 연결됨 → 비디오-투-비디오 (v2v)
- `source_video` + `reference_images` → 참조 기반 비디오 편집 (rv2v)
- `reference_images`만 연결됨 → 참조-투-비디오 (r2v)
- `source_video` + `reference_video` → 비디오에 이미지/비디오 삽입 (ads2v)
컨텍스트 스트림은 고정된 순서로 첨부됩니다: `source_video`(소스 ID 1), 그 다음 `reference_video`(소스 ID 2), 그 다음 각 참조 이미지(소스 ID 3, 4, ...). 여러 이미지를 포함하는 참조 이미지 입력은 이미지당 하나의 스트림을 제공합니다.

## 출력

| 출력 이름 | 설명 | 데이터 타입 |
|-------------|-------------|-----------|
| `positive` | 컨텍스트 잠재 변수가 첨부된 긍정 컨디셔닝 | CONDITIONING |
| `negative` | 컨텍스트 잠재 변수가 첨부된 부정 컨디셔닝 | CONDITIONING |
| `latent` | 지정된 너비, 높이, 길이 및 배치 크기와 일치하는 차원의 빈 잠재 변수 텐서 | LATENT |

> 이 문서는 AI에 의해 생성되었습니다. 오류를 발견하거나 개선 제안이 있으시면 기여해 주세요! [GitHub에서 편집](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BerniniConditioning/ko.md)

---
**Source fingerprint (SHA-256):** `3535bbe9a1ae007dc579242b44787ab315479a820eb0da680eab9b870ab60699`
