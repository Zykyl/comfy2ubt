# 批量latent

Batch Latents 节点将多个 latent 输入合并为一个批次。它接受可变数量的 latent 样本，并沿批次维度将它们合并，以便后续节点可以一起处理。该节点还会将所有输入的批次索引元数据合并到组合输出中。

## 输入

| 参数 | 描述 | 数据类型 | 必需 | 范围 |
| --- | --- | --- | --- | --- |
| `latent` | 一组要合并为单个批次的 latent 样本。您必须至少提供一个 latent，最多可添加 50 个。随着您连接更多 latent，节点会自动创建输入槽（`latent_1`、`latent_2` 等）。 | LATENT | 是 | 1 到 50 inputs |

**注意：** 您必须至少提供一个 latent 输入，节点才能正常工作。随着您连接更多 latent，节点会自动创建输入槽，最多 50 个。每个输入 latent 在合并前都会调整为与第一个 latent 的样本形状一致，任何没有批次索引元数据的 latent 都会被分配一个顺序批次索引。输入 latent 沿批次维度连接，以生成合并结果。

## 输出

| 输出名称 | 描述 | 数据类型 |
| --- | --- | --- |
| `output` | 一个单独的 latent 输出，包含所有输入 latent 合并为一个批次后的结果，以及它们合并后的批次索引元数据。 | LATENT |

> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BatchLatentsNode/zh.md)

---
**Source fingerprint (SHA-256):** `38df5e6cfa391e054c663af1cc55728d115cebfbb804e1c2c51dfc2aab37df47`
